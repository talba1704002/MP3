# Party Sync
Host: live system audio (UDP, 5 ms packets, jitter buffer, loss concealment) or music library (queue/shuffle/seek, chunked upload, clock-synced start).
Join: auto-discovery or IP, PIN, heartbeat + auto-reconnect with backoff, latency trim.
Network: DSCP-EF marking, Wi-Fi low-latency lock, process pinned to Wi-Fi, band indicator (5 GHz recommended).
Build: push to GitHub; .github/workflows/build.yml builds the APK.

Listener controls: the host can switch "Let listeners control playback" on/off (Player tab, or the Now Playing screen). When on, listeners get a controller (play/pause, prev/next, -10s/+10s, seek bar) that mirrors the host's player. Not available during live system audio.
