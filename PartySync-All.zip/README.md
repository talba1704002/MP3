# Party Sync
Host: live system audio (UDP, 5 ms packets, jitter buffer, loss concealment) or music library (queue/shuffle/seek, chunked upload, clock-synced start).
Join: auto-discovery or IP, PIN, heartbeat + auto-reconnect with backoff, latency trim.
Network: DSCP-EF marking, Wi-Fi low-latency lock, process pinned to Wi-Fi, band indicator (5 GHz recommended).
Build: push to GitHub; .github/workflows/build.yml builds the APK.
