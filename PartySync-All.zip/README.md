# Party Sync
Sync music/system audio across phones on one Wi-Fi.
Host: system audio (MediaProjection) or your music library (queue, shuffle, seek, auto-next).
Receiver: auto-discovery or IP, optional PIN, auto-reconnect, latency trim for Bluetooth speakers.
Build: push to GitHub, Actions builds the debug APK (see .github/workflows/build.yml).
