plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.partysync"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.partysync"
        minSdk = 29          // AudioPlaybackCapture needs Android 10+
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.google.zxing:core:3.5.3")                          // draws the host QR code
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0") // in-app QR scanner (Google Play services)
}
