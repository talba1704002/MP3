package com.example.partysync

import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.media.*
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import java.io.*
import java.net.*
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

const val PORT = 45454
const val SVC = "_partysync._tcp."
const val RATE = 48000      // native low-latency rate on almost all phones
const val FRAME = 960       // PCM bytes per UDP packet = 5 ms stereo 16-bit (fits one Wi-Fi frame, no fragmentation)
fun now() = SystemClock.elapsedRealtime()

/** Shared UI state, polled by the activity. */
object Ui { @Volatile var status = "Idle"; @Volatile var listeners = 0; @Volatile var title = ""; @Volatile var syncVol = true }

// Protocol. TCP = control + library files; UDP = live system audio.
// Client->Host on connect: UTF pin, int udpPort.  0 PING(t0)  |  1 PONG(t0,hostNow)  2 META(id,size,title)
// 3 CHUNK(len,bytes)  4 PLAY(id,startAt)  5 PAUSE  6 PCMCFG(rate,ch)  8 BAD_PIN
// UDP packet: int seq + PCM bytes.

@Suppress("DEPRECATION")
fun wifiBand(ctx: Context): Pair<String, Boolean> {
    val f = ctx.applicationContext.getSystemService(WifiManager::class.java).connectionInfo?.frequency ?: -1
    return when { f > 5900 -> "6 GHz" to true; f > 4900 -> "5 GHz" to true; f > 0 -> "2.4 GHz" to false; else -> "Hotspot / no Wi-Fi" to false }
}

data class Song(val id: Long, val title: String, val size: Long, val dur: Long) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

fun scanSongs(ctx: Context): List<Song> {
    val out = ArrayList<Song>()
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DURATION),
        "${MediaStore.Audio.Media.IS_MUSIC}!=0", null, "${MediaStore.Audio.Media.TITLE} ASC"
    )?.use { c -> while (c.moveToNext()) out += Song(c.getLong(0), c.getString(1) ?: "?", c.getLong(2), c.getLong(3)) }
    return out
}

fun localIp(): String {
    val ifs = NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
    fun ip(n: NetworkInterface) = n.inetAddresses.toList().firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
    // prefer the Wi-Fi / hotspot interface over mobile-data or virtual ones
    return ifs.filter { it.name.startsWith("wlan") || it.name.startsWith("ap") || it.name.startsWith("swlan") }.firstNotNullOfOrNull { ip(it) }
        ?: ifs.firstNotNullOfOrNull { ip(it) } ?: "?"
}

class Peer(val sock: Socket) {
    val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream(), 65536))
    val inp = DataInputStream(BufferedInputStream(sock.getInputStream(), 65536))
    val have = HashSet<Long>()
    @Volatile var udpPort = 0
    @Volatile var name = "?"
    @Volatile var muted = false
    @Synchronized fun send(f: DataOutputStream.() -> Unit) {
        try { out.f(); out.flush() } catch (e: IOException) { close() }
    }
    fun close() = try { sock.close() } catch (_: Exception) {}
}

/** Plays a local file so that position == now() - startAt (local clock). */
class SyncPlayer(val ctx: Context) {
    private var mp: MediaPlayer? = null
    private var key: String? = null
    @Volatile private var gainL = 1f
    @Volatile private var gainR = 1f
    private val h = Handler(Looper.getMainLooper())

    fun play(uri: Uri, startAt: Long) { h.post {
        val pos = now() - startAt
        if (key != uri.toString() || mp == null) { mp?.release(); mp = MediaPlayer.create(ctx, uri); mp?.setVolume(gainL, gainR); key = uri.toString() }
        val m = mp ?: return@post
        h.removeCallbacksAndMessages(null)
        if (pos < 0) { m.pause(); m.seekTo(0); h.postDelayed({ m.start() }, -pos) }
        else if (!m.isPlaying || Math.abs(m.currentPosition - pos) > 60) { m.seekTo(pos, MediaPlayer.SEEK_CLOSEST); m.start() }
    } }
    fun setGain(l: Float, r: Float) { gainL = l; gainR = r; h.post { mp?.setVolume(l, r) } }
    fun pause() { h.post { h.removeCallbacksAndMessages(null); mp?.pause() } }
    fun release() { h.post { h.removeCallbacksAndMessages(null); mp?.release(); mp = null } }
}

class Host(val ctx: Context, val player: SyncPlayer) {
    private val peers = CopyOnWriteArrayList<Peer>()
    private var server: ServerSocket? = null
    private var reg: NsdManager.RegistrationListener? = null
    private val udp = DatagramSocket().apply { trafficClass = 0xB8 } // DSCP EF -> Wi-Fi "voice" queue = lower latency
    private val pkt = ByteArray(4 + FRAME)
    private var seq = 0
    @Volatile private var alive = true
    @Volatile var cfg: Pair<Int, Int>? = null
    @Volatile var cur: Song? = null
    @Volatile var startAt = 0L
    @Volatile var playing = false
    @Volatile var pausedPos = 0L
    @Volatile var pin = ""
    private var volObs: ContentObserver? = null
    private var lastV = -1f
    var queue = listOf<Song>()
    var idx = -1

    private fun bc(f: DataOutputStream.() -> Unit) = peers.forEach { it.send(f) }
    private fun info() { Ui.listeners = peers.size; Ui.status = "Hosting at ${localIp()}:$PORT" }
    fun listeners(): List<Peer> = peers.toList()
    fun kick(p: Peer) = p.close()
    fun mute(p: Peer, m: Boolean) { p.muted = m; p.send { writeByte(10); writeByte(if (m) 1 else 0) } }
    private fun volFrac(): Float { val am = ctx.getSystemService(AudioManager::class.java)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    /** Sends the host's media volume (0..1) to every listener, if "Sync volume" is on. */
    fun pushVolume() { if (Ui.syncVol) { val v = volFrac(); bc { writeByte(9); writeFloat(v) } } }
    fun pos() = if (playing) now() - startAt else pausedPos

    fun start() {
        val ss = ServerSocket(PORT); server = ss
        val rl = object : NsdManager.RegistrationListener {
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
        }
        reg = rl
        ctx.getSystemService(NsdManager::class.java).registerService(
            NsdServiceInfo().apply { serviceName = "PartySync"; serviceType = SVC; port = PORT }, NsdManager.PROTOCOL_DNS_SD, rl)
        info()
        // Physical volume buttons change the system volume -> this observer fires (works with screen off too)
        volObs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(self: Boolean) { val v = volFrac(); if (v != lastV) { lastV = v; pushVolume() } }
        }.also { ctx.contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, it) }
        thread { while (alive) {
            val s = try { ss.accept() } catch (e: Exception) { break }
            Ui.status = "Incoming connection from ${s.inetAddress.hostAddress}"
            s.tcpNoDelay = true; s.keepAlive = true; s.soTimeout = 8000 // dead listeners are dropped after 8 s
            thread { serve(Peer(s)) }
        } }
        thread { var t = 0; while (alive) { // resync every 3 s + auto-advance the queue
            Thread.sleep(500)
            val c = cur
            if (playing && c != null) {
                if (c.dur > 0 && now() - startAt >= c.dur - 300) { next(); continue }
                if (++t % 6 == 0) bc { writeByte(4); writeLong(c.id); writeLong(startAt) }
            }
        } }
    }

    private fun serve(p: Peer) {
        try {
            if (p.inp.readUTF() != pin) { Ui.status = "Rejected ${p.sock.inetAddress.hostAddress}: wrong PIN"; p.send { writeByte(8) }; return }
            p.udpPort = p.inp.readInt(); p.name = p.inp.readUTF()
            peers.add(p); info()
            if (Ui.syncVol) { val v = volFrac(); p.send { writeByte(9); writeFloat(v) } }
            cfg?.let { c -> p.send { writeByte(6); writeInt(c.first); writeInt(c.second) } }
            cur?.let { c ->
                sendFile(c, listOf(p))
                if (playing) p.send { writeByte(4); writeLong(c.id); writeLong(startAt) }
            }
            while (true) if (p.inp.readByte().toInt() == 0) {
                val t0 = p.inp.readLong(); p.send { writeByte(1); writeLong(t0); writeLong(now()) }
            }
        } catch (_: Exception) {
        } finally { peers.remove(p); p.close(); if (alive) info() }
    }

    private fun sendFile(s: Song, to: List<Peer>) {
        val t = to.filter { s.id !in it.have }; if (t.isEmpty()) return
        t.forEach { it.send { writeByte(2); writeLong(s.id); writeLong(s.size); writeUTF(s.title) } }
        var sent = 0L
        ctx.contentResolver.openInputStream(s.uri)?.use { i ->
            val b = ByteArray(65536)
            while (true) {
                val n = i.read(b); if (n < 0) break
                t.forEach { it.send { writeByte(3); writeInt(n); write(b, 0, n) } }
                sent += n; Ui.status = "Uploading ${s.title}: ${sent * 100 / s.size.coerceAtLeast(1)}%"
            }
        }
        t.forEach { it.have.add(s.id) }
        info()
    }

    fun playSong(s: Song) { thread {
        playing = false
        sendFile(s, peers.toList())
        cur = s; Ui.title = s.title; startAt = now() + 1500; playing = true
        bc { writeByte(4); writeLong(s.id); writeLong(startAt) }
        player.play(s.uri, startAt)
    } }
    fun playQueue(l: List<Song>, i: Int) { queue = l; idx = i; l.getOrNull(i)?.let { playSong(it) } }
    fun next() { if (queue.isNotEmpty()) playQueue(queue, (idx + 1) % queue.size) }
    fun prev() { if (queue.isNotEmpty()) playQueue(queue, (idx - 1 + queue.size) % queue.size) }
    fun seekBy(ms: Long) {
        val c = cur ?: return; if (!playing) return
        startAt = now() - (now() - startAt + ms).coerceIn(0L, c.dur)
        bc { writeByte(4); writeLong(c.id); writeLong(startAt) }; player.play(c.uri, startAt)
    }
    fun pause() { playing = false; pausedPos = now() - startAt; bc { writeByte(5) }; player.pause() }
    fun resume() {
        val c = cur ?: return
        startAt = now() + 800 - pausedPos; playing = true
        bc { writeByte(4); writeLong(c.id); writeLong(startAt) }; player.play(c.uri, startAt)
    }

    fun setPcm(rate: Int, ch: Int) { cfg = rate to ch; Ui.title = "System audio"; bc { writeByte(6); writeInt(rate); writeInt(ch) } }
    /** Live audio goes out as fire-and-forget UDP: no head-of-line blocking, one slow phone can't stall the rest. */
    fun sendPcm(b: ByteArray, n: Int) {
        seq++
        pkt[0] = (seq ushr 24).toByte(); pkt[1] = (seq ushr 16).toByte(); pkt[2] = (seq ushr 8).toByte(); pkt[3] = seq.toByte()
        System.arraycopy(b, 0, pkt, 4, n)
        for (p in peers) if (p.udpPort != 0) try { udp.send(DatagramPacket(pkt, 4 + n, p.sock.inetAddress, p.udpPort)) } catch (_: IOException) {}
    }

    fun stop() {
        alive = false
        try { server?.close() } catch (_: Exception) {}
        peers.forEach { it.close() }; udp.close()
        volObs?.let { ctx.contentResolver.unregisterContentObserver(it) }
        try { reg?.let { ctx.getSystemService(NsdManager::class.java).unregisterService(it) } } catch (_: Exception) {}
        player.release(); Ui.listeners = 0
    }
}

class Client(val ctx: Context, val player: SyncPlayer, val pin: String = "") {
    @Volatile var offset = 0L // hostClock - localClock
    @Volatile var hostVol = -1f
    @Volatile var muted = false
    @Volatile var ch = 0 // 0 = both, 1 = left only, 2 = right only
    @Volatile private var target = 8 // adaptive jitter buffer (x5 ms)
    @Volatile var trim = 0L   // + = play earlier (compensates slow speakers/Bluetooth)
    @Volatile private var stopped = false
    @Volatile private var track: AudioTrack? = null
    @Volatile private var lastSeq = 0
    private var peer: Peer? = null
    private val q = LinkedBlockingQueue<ByteArray>()
    private val titles = HashMap<Long, String>()
    private fun file(id: Long) = File(ctx.cacheDir, "party_$id")

    fun connect(ip: String) { thread { var fails = 0; while (!stopped) {
        var udp: DatagramSocket? = null
        try {
            val s = Socket(); s.connect(InetSocketAddress(ip, PORT), 3000)
            s.tcpNoDelay = true; s.keepAlive = true; s.soTimeout = 6000 // no host traffic for 6 s -> reconnect
            val u = DatagramSocket().apply { trafficClass = 0xB8 }; udp = u
            val p = Peer(s); peer = p; fails = 0; lastSeq = 0; q.clear()
            Ui.status = "Connected to $ip"
            p.send { writeUTF(pin); writeInt(u.localPort); writeUTF(Build.MODEL) }
            thread { udpRx(u) }; thread { playLoop(u) }
            thread { var i = 0; while (!s.isClosed) {
                val t = now(); p.send { writeByte(0); writeLong(t) }
                Thread.sleep(if (i++ < 8) 500 else 2000)
            } }
            val d = p.inp
            var out: OutputStream? = null; var left = 0L; var id = 0L; var best = Long.MAX_VALUE / 2
            val ready = HashSet<Long>()
            while (true) when (d.readByte().toInt()) {
                1 -> { // NTP-style clock sync, trusting the lowest-RTT samples
                    val t0 = d.readLong(); val h = d.readLong(); val t1 = now(); val rtt = t1 - t0
                    best = minOf(best + 1, rtt)
                    if (rtt <= best + 4) offset = h - (t0 + t1) / 2
                }
                2 -> { out?.close(); id = d.readLong(); left = d.readLong(); titles[id] = d.readUTF(); out = FileOutputStream(file(id)); Ui.status = "Receiving: ${titles[id]}" }
                3 -> {
                    val n = d.readInt(); val b = ByteArray(n); d.readFully(b)
                    out?.write(b); left -= n
                    if (left <= 0) { out?.close(); out = null; ready.add(id); Ui.status = "Song ready" }
                }
                4 -> { val sid = d.readLong(); val at = d.readLong()
                    if (sid in ready) { player.play(Uri.fromFile(file(sid)), at - offset - trim); Ui.title = titles[sid] ?: ""; Ui.status = "Playing in sync (trim $trim ms)" } }
                5 -> player.pause()
                6 -> { startTrack(d.readInt(), d.readInt()); Ui.title = "System audio"; Ui.status = "Streaming live" }
                10 -> { muted = d.readByte().toInt() == 1; applyGain() }
                9 -> { hostVol = d.readFloat(); if (Ui.syncVol) applyVol() }
                8 -> { stopped = true; Ui.status = "Wrong PIN"; s.close() }
            }
        } catch (e: Exception) { if (!stopped) Ui.status = "Can't reach $ip:$PORT (${e.javaClass.simpleName}) — retrying" }
        finally { udp?.close() }
        if (!stopped) Thread.sleep(minOf(1000L shl minOf(fails++, 3), 5000L))
    } } }

    fun setChannel(c: Int) { ch = c; applyGain() }
    private fun applyGain() { val m = if (muted) 0f else 1f; player.setGain(if (ch == 2) 0f else m, if (ch == 1) 0f else m) }

    /** Mirrors the host's volume onto this phone's media volume. */
    fun applyVol() { if (hostVol < 0) return; try {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(hostVol * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)), 0)
    } catch (_: Exception) {} }

    private fun udpRx(u: DatagramSocket) {
        val buf = ByteArray(4 + FRAME + 64); val dp = DatagramPacket(buf, buf.size)
        while (!u.isClosed) {
            try { u.receive(dp) } catch (e: IOException) { break }
            if (dp.length <= 4) continue
            val sq = ((buf[0].toInt() and 255) shl 24) or ((buf[1].toInt() and 255) shl 16) or ((buf[2].toInt() and 255) shl 8) or (buf[3].toInt() and 255)
            if (lastSeq != 0 && sq <= lastSeq) continue                       // late or duplicate
            if (lastSeq != 0) repeat(minOf(sq - lastSeq - 1, 4)) { q.offer(ByteArray(FRAME)) } // conceal loss with silence
            lastSeq = sq; q.offer(buf.copyOfRange(4, dp.length))
            if (q.size > 24) repeat(12) { q.poll() }                          // cap latency at ~120 ms
        }
    }

    private fun playLoop(u: DatagramSocket) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        var primed = false; var lastAdj = now()
        while (!u.isClosed) {
            val t = track
            if (t == null) { Thread.sleep(20); continue }
            if (!primed) { if (q.size < target) { Thread.sleep(2); continue }; primed = true } // 40 ms jitter buffer
            val b = q.poll(50, TimeUnit.MILLISECONDS)
            if (b == null) { primed = false; target = minOf(target + 2, 16); lastAdj = now(); continue } // Wi-Fi hiccup: grow buffer                       // underrun: rebuffer
            if (muted) java.util.Arrays.fill(b, 0)
            else if (ch != 0) { var i = if (ch == 2) 0 else 2; while (i + 1 < b.size) { b[i] = 0; b[i + 1] = 0; i += 4 } } // stereo split
            t.write(b, 0, b.size)
            if (now() - lastAdj > 3000) { target = maxOf(6, target - 1); lastAdj = now() } // calm Wi-Fi: shrink buffer
        }
    }

    private fun startTrack(rate: Int, ch: Int) {
        track?.release(); q.clear()
        val mask = if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask).build())
            .setBufferSizeInBytes(maxOf(min, FRAME * 3)).setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build().also { it.play() }
    }

    fun stop() { stopped = true; peer?.close(); track?.release(); player.release()
        ctx.cacheDir.listFiles()?.filter { it.name.startsWith("party_") }?.forEach { it.delete() } }
}

class Discovery(ctx: Context, val onFound: (String) -> Unit) {
    private val nsd = ctx.getSystemService(NsdManager::class.java)
    private val l = object : NsdManager.DiscoveryListener {
        override fun onServiceFound(i: NsdServiceInfo) {
            nsd.resolveService(i, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceResolved(r: NsdServiceInfo) { r.host?.hostAddress?.let(onFound) }
            })
        }
        override fun onServiceLost(i: NsdServiceInfo) {}
        override fun onDiscoveryStarted(t: String) {}
        override fun onDiscoveryStopped(t: String) {}
        override fun onStartDiscoveryFailed(t: String, e: Int) {}
        override fun onStopDiscoveryFailed(t: String, e: Int) {}
    }
    fun start() = nsd.discoverServices(SVC, NsdManager.PROTOCOL_DNS_SD, l)
    fun stop() = try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {}
}
