package com.example.partysync

import android.content.ContentUris
import android.content.Context
import android.media.*
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import java.io.*
import java.net.*
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

const val PORT = 45454
const val SVC = "_partysync._tcp."
fun now() = SystemClock.elapsedRealtime()

// Wire protocol (host -> client unless noted):
// 0 PING(t0) [client->host]   1 PONG(t0, hostNow)
// 2 META(id, size)            3 CHUNK(len, bytes)   <- song uploaded in 64 KB parts
// 4 PLAY(id, startAt)         position = hostNow - startAt (also sent every 3 s for drift fix)
// 5 PAUSE                     6 PCMCFG(rate, channels)   7 PCM(len, bytes)

data class Song(val id: Long, val title: String, val size: Long, val dur: Long) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

fun scanSongs(ctx: Context): List<Song> {
    val out = ArrayList<Song>()
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DURATION),
        "${MediaStore.Audio.Media.IS_MUSIC}!=0", null, "${MediaStore.Audio.Media.TITLE} ASC"
    )?.use { c -> while (c.moveToNext()) out += Song(c.getLong(0), c.getString(1) ?: "?", c.getLong(2), c.getLong(3)) }
    return out
}

fun localIp(): String = NetworkInterface.getNetworkInterfaces().toList()
    .flatMap { it.inetAddresses.toList() }
    .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress ?: "?"

class Peer(val sock: Socket) {
    val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream(), 65536))
    val inp = DataInputStream(BufferedInputStream(sock.getInputStream(), 65536))
    val have = HashSet<Long>()
    @Synchronized fun send(f: DataOutputStream.() -> Unit) {
        try { out.f(); out.flush() } catch (e: IOException) { close() }
    }
    fun close() = try { sock.close() } catch (_: Exception) {}
}

/** Plays a local file so that position == now() - startAt (local clock). */
class SyncPlayer(val ctx: Context) {
    private var mp: MediaPlayer? = null
    private var key: String? = null
    private val h = Handler(Looper.getMainLooper())

    fun play(uri: Uri, startAt: Long) { h.post {
        val pos = now() - startAt
        if (key != uri.toString() || mp == null) { mp?.release(); mp = MediaPlayer.create(ctx, uri); key = uri.toString() }
        val m = mp ?: return@post
        h.removeCallbacksAndMessages(null)
        if (pos < 0) { m.pause(); m.seekTo(0); h.postDelayed({ m.start() }, -pos) }
        else if (!m.isPlaying || Math.abs(m.currentPosition - pos) > 60) { m.seekTo(pos, MediaPlayer.SEEK_CLOSEST); m.start() }
    } }
    fun pause() { h.post { h.removeCallbacksAndMessages(null); mp?.pause() } }
    fun release() { h.post { h.removeCallbacksAndMessages(null); mp?.release(); mp = null } }
}

class Host(val ctx: Context, val player: SyncPlayer, val log: (String) -> Unit) {
    private val peers = CopyOnWriteArrayList<Peer>()
    private var server: ServerSocket? = null
    private var reg: NsdManager.RegistrationListener? = null
    @Volatile private var alive = true
    @Volatile var cfg: Pair<Int, Int>? = null
    @Volatile var cur: Song? = null
    @Volatile var startAt = 0L
    @Volatile var playing = false
    private var pausedPos = 0L
    @Volatile var pin = ""
    var queue = listOf<Song>()
    var idx = -1

    private fun bc(f: DataOutputStream.() -> Unit) = peers.forEach { it.send(f) }

    fun start() {
        val ss = ServerSocket(PORT); server = ss
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val rl = object : NsdManager.RegistrationListener {
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
        }
        reg = rl
        nsd.registerService(NsdServiceInfo().apply { serviceName = "PartySync"; serviceType = SVC; port = PORT },
            NsdManager.PROTOCOL_DNS_SD, rl)
        thread { while (alive) {
            val s = try { ss.accept() } catch (e: Exception) { break }
            s.tcpNoDelay = true
            thread { serve(Peer(s)) }
        } }
        thread { var t = 0; while (alive) { // resync every 3 s + auto-advance the queue
            Thread.sleep(500)
            val c = cur
            if (playing && c != null) {
                if (c.dur > 0 && now() - startAt >= c.dur - 300) { next(); continue }
                if (++t % 6 == 0) bc { writeByte(4); writeLong(c.id); writeLong(startAt) }
            }
        } }
    }

    private fun serve(p: Peer) {
        try {
            if (p.inp.readUTF() != pin) { p.send { writeByte(8) }; return } // PIN check
            peers.add(p); log("Hosting at ${localIp()}:$PORT — ${peers.size} listener(s)")
            cfg?.let { c -> p.send { writeByte(6); writeInt(c.first); writeInt(c.second) } }
            cur?.let { c ->
                sendFile(c, listOf(p))
                if (playing) p.send { writeByte(4); writeLong(c.id); writeLong(startAt) }
            }
            while (true) if (p.inp.readByte().toInt() == 0) {
                val t0 = p.inp.readLong(); p.send { writeByte(1); writeLong(t0); writeLong(now()) }
            }
        } catch (_: Exception) {
        } finally { peers.remove(p); p.close(); log("Hosting at ${localIp()}:$PORT — ${peers.size} listener(s)") }
    }

    private fun sendFile(s: Song, to: List<Peer>) {
        val t = to.filter { s.id !in it.have }; if (t.isEmpty()) return
        t.forEach { it.send { writeByte(2); writeLong(s.id); writeLong(s.size); writeUTF(s.title) } }
        var sent = 0L
        ctx.contentResolver.openInputStream(s.uri)?.use { i ->
            val b = ByteArray(65536)
            while (true) {
                val n = i.read(b); if (n < 0) break
                t.forEach { it.send { writeByte(3); writeInt(n); write(b, 0, n) } }
                sent += n; log("Uploading ${s.title}: ${sent * 100 / s.size.coerceAtLeast(1)}%")
            }
        }
        t.forEach { it.have.add(s.id) }
    }

    fun playSong(s: Song) { thread {
        playing = false
        sendFile(s, peers.toList())
        cur = s; startAt = now() + 1500; playing = true
        bc { writeByte(4); writeLong(s.id); writeLong(startAt) }
        player.play(s.uri, startAt); log("Playing ${s.title}")
    } }

    fun playQueue(l: List<Song>, i: Int) { queue = l; idx = i; l.getOrNull(i)?.let { playSong(it) } }
    fun next() { if (queue.isNotEmpty()) playQueue(queue, (idx + 1) % queue.size) }
    fun prev() { if (queue.isNotEmpty()) playQueue(queue, (idx - 1 + queue.size) % queue.size) }
    fun seekBy(ms: Long) {
        val c = cur ?: return; if (!playing) return
        startAt = now() - (now() - startAt + ms).coerceIn(0L, c.dur)
        bc { writeByte(4); writeLong(c.id); writeLong(startAt) }; player.play(c.uri, startAt)
    }
    fun pause() { playing = false; pausedPos = now() - startAt; bc { writeByte(5) }; player.pause() }
    fun resume() {
        val c = cur ?: return
        startAt = now() + 800 - pausedPos; playing = true
        bc { writeByte(4); writeLong(c.id); writeLong(startAt) }; player.play(c.uri, startAt)
    }

    fun setPcm(rate: Int, ch: Int) { cfg = rate to ch; bc { writeByte(6); writeInt(rate); writeInt(ch) } }
    fun sendPcm(b: ByteArray, n: Int) = bc { writeByte(7); writeInt(n); write(b, 0, n) }

    fun stop() {
        alive = false
        try { server?.close() } catch (_: Exception) {}
        peers.forEach { it.close() }
        try { reg?.let { ctx.getSystemService(NsdManager::class.java).unregisterService(it) } } catch (_: Exception) {}
        player.release()
    }
}

class Client(val ctx: Context, val player: SyncPlayer, val log: (String) -> Unit, val pin: String = "") {
    @Volatile var offset = 0L // hostClock - localClock
    @Volatile var trim = 0L // + = play earlier (compensates slow speakers/Bluetooth)
    @Volatile private var stopped = false
    private val titles = HashMap<Long, String>()
    private var peer: Peer? = null
    private var track: AudioTrack? = null
    private fun file(id: Long) = File(ctx.cacheDir, "party_$id")

    fun connect(ip: String) { thread { while (!stopped) {
        try {
            val s = Socket(); s.connect(InetSocketAddress(ip, PORT), 4000); s.tcpNoDelay = true
            val p = Peer(s); peer = p; log("Connected to $ip"); p.send { writeUTF(pin) }
            thread { var i = 0; while (!s.isClosed) {
                val t = now(); p.send { writeByte(0); writeLong(t) }
                Thread.sleep(if (i++ < 8) 500 else 5000)
            } }
            val d = p.inp
            var out: OutputStream? = null; var left = 0L; var id = 0L; var best = Long.MAX_VALUE / 2
            val ready = HashSet<Long>()
            while (true) when (d.readByte().toInt()) {
                1 -> { // NTP-style clock sync, trusting the lowest-RTT samples
                    val t0 = d.readLong(); val h = d.readLong(); val t1 = now(); val rtt = t1 - t0
                    best = minOf(best + 1, rtt)
                    if (rtt <= best + 4) offset = h - (t0 + t1) / 2
                }
                2 -> { out?.close(); id = d.readLong(); left = d.readLong(); titles[id] = d.readUTF(); out = FileOutputStream(file(id)); log("Receiving: ${titles[id]}") }
                3 -> {
                    val n = d.readInt(); val b = ByteArray(n); d.readFully(b)
                    out?.write(b); left -= n
                    if (left <= 0) { out?.close(); out = null; ready.add(id); log("Song ready") }
                }
                4 -> { val sid = d.readLong(); val at = d.readLong()
                    if (sid in ready) { player.play(Uri.fromFile(file(sid)), at - offset - trim); log("♪ ${titles[sid]}  (trim $trim ms)") } }
                5 -> player.pause()
                8 -> { stopped = true; log("Wrong PIN"); s.close() }
                6 -> { val rate = d.readInt(); val ch = d.readInt(); startTrack(rate, ch); log("Streaming system audio") }
                7 -> { val n = d.readInt(); val b = ByteArray(n); d.readFully(b); track?.write(b, 0, n) }
            }
        } catch (e: Exception) { if (!stopped) log("Reconnecting… (${e.message})") }
        if (!stopped) Thread.sleep(2000)
    } } }

    private fun startTrack(rate: Int, ch: Int) {
        track?.release()
        val mask = if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask).build())
            .setBufferSizeInBytes(min * 4).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
    }

    fun stop() { stopped = true; peer?.close(); track?.release(); player.release()
        ctx.cacheDir.listFiles()?.filter { it.name.startsWith("party_") }?.forEach { it.delete() } }
}

class Discovery(ctx: Context, val onFound: (String) -> Unit) {
    private val nsd = ctx.getSystemService(NsdManager::class.java)
    private val l = object : NsdManager.DiscoveryListener {
        override fun onServiceFound(i: NsdServiceInfo) {
            nsd.resolveService(i, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceResolved(r: NsdServiceInfo) { r.host?.hostAddress?.let(onFound) }
            })
        }
        override fun onServiceLost(i: NsdServiceInfo) {}
        override fun onDiscoveryStarted(t: String) {}
        override fun onDiscoveryStopped(t: String) {}
        override fun onStartDiscoveryFailed(t: String, e: Int) {}
        override fun onStopDiscoveryFailed(t: String, e: Int) {}
    }
    fun start() = nsd.discoverServices(SVC, NsdManager.PROTOCOL_DNS_SD, l)
    fun stop() = try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {}
}
