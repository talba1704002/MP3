package com.example.partysync

import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Intent
import android.content.IntentFilter
import android.content.Context
import android.database.ContentObserver
import android.media.*
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import java.io.*
import java.net.*
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

const val PORT = 45454
const val INFO_Q = "\u0000INFO" // discovery query: host answers with party name + lock flag
const val SVC = "_partysync._tcp."
const val RATE = 48000      // native low-latency rate on almost all phones
const val MAXPKT = 1440    // largest packet the host may choose (keeps UDP under the 1472-byte Wi-Fi MTU limit)
val PKT_SIZES = intArrayOf(120, 240, 480, 960, 1440) // selectable packet sizes: 0.6 / 1.25 / 2.5 / 5 / 7.5 ms
const val FRAME = 480       // PCM bytes per UDP packet = 2.5 ms stereo 16-bit @ 48 kHz (tiny packets = minimal packetization delay)
fun now() = SystemClock.elapsedRealtime()

/** Shared UI state, polled by the activity. */
object Ui { @Volatile var status = "Idle"; @Volatile var listeners = 0; @Volatile var title = ""; @Volatile var syncVol = true }

// Protocol. TCP = control + library files; UDP = live system audio.
// Client->Host on connect: UTF pin, int udpPort.  0 PING(t0)  |  1 PONG(t0,hostNow)  2 META(id,size,title)
// 3 CHUNK(len,bytes)  4 PLAY(id,startAt)  5 PAUSE  6 PCMCFG(rate,ch)  8 BAD_PIN
// UDP packet: int seq + PCM bytes.

@Suppress("DEPRECATION")
fun wifiBand(ctx: Context): Pair<String, Boolean> {
    val f = ctx.applicationContext.getSystemService(WifiManager::class.java).connectionInfo?.frequency ?: -1
    return when { f > 5900 -> "6 GHz" to true; f > 4900 -> "5 GHz" to true; f > 0 -> "2.4 GHz" to false; else -> "Hotspot / no Wi-Fi" to false }
}

data class Song(val id: Long, val title: String, val size: Long, val dur: Long, val artist: String = "", val album: String = "") {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

fun scanSongs(ctx: Context): List<Song> {
    val out = ArrayList<Song>()
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM),
        "${MediaStore.Audio.Media.IS_MUSIC}!=0", null, "${MediaStore.Audio.Media.TITLE} ASC"
    )?.use { c -> while (c.moveToNext()) out += Song(c.getLong(0), c.getString(1) ?: "?", c.getLong(2), c.getLong(3),
        (c.getString(4) ?: "").let { if (it.isEmpty() || it == "<unknown>") "Unknown artist" else it },
        (c.getString(5) ?: "").let { if (it.isEmpty() || it == "<unknown>") "Unknown album" else it }) }
    return out
}

fun localIp(): String {
    val ifs = NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
    fun ip(n: NetworkInterface) = n.inetAddresses.toList().firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
    // prefer the Wi-Fi / hotspot interface over mobile-data or virtual ones
    return ifs.filter { it.name.startsWith("wlan") || it.name.startsWith("ap") || it.name.startsWith("swlan") }.firstNotNullOfOrNull { ip(it) }
        ?: ifs.firstNotNullOfOrNull { ip(it) } ?: "?"
}

class Peer(val sock: Socket) {
    val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream(), 65536))
    val inp = DataInputStream(BufferedInputStream(sock.getInputStream(), 65536))
    val have = HashSet<Long>()
    @Volatile var udpPort = 0
    @Volatile var name = "?"
    @Volatile var dp: DatagramPacket? = null
    @Volatile var gain = 1f
    @Volatile var muted = false
    @Synchronized fun send(f: DataOutputStream.() -> Unit) {
        try { out.f(); out.flush() } catch (e: IOException) { close() }
    }
    fun close() = try { sock.close() } catch (_: Exception) {}
}

/** Plays a local file so that position == now() - startAt (local clock). */
class SyncPlayer(val ctx: Context) {
    private var mp: MediaPlayer? = null
    private var key: String? = null
    @Volatile private var gainL = 1f
    @Volatile private var gainR = 1f
    private val h = Handler(Looper.getMainLooper())

    private fun openPlayer(uri: Uri): MediaPlayer? = try {
        MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            setDataSource(ctx, uri); setVolume(gainL, gainR)
            setOnErrorListener { _, what, extra -> Ui.status = "Playback error ($what/$extra)"; true }
            prepare()
        }
    } catch (e: Exception) { Ui.status = "Can't play this song: ${e.javaClass.simpleName} ${e.message ?: ""}"; null }

    fun play(uri: Uri, startAt: Long) { h.post {
        try {
            val pos = now() - startAt
            if (key != uri.toString() || mp == null) { mp?.release(); mp = openPlayer(uri); key = if (mp != null) uri.toString() else null
                mp?.let { Fx.attach(it.audioSessionId); outputDevice(ctx)?.let { d -> it.setPreferredDevice(d) } } }
            val m = mp ?: return@post
            h.removeCallbacksAndMessages(null)
            if (pos < 0) { m.pause(); m.seekTo(0); h.postDelayed({ try { m.start() } catch (_: Exception) {} }, -pos) }
            else if (!m.isPlaying || Math.abs(m.currentPosition - pos) > Cfg.drift) { m.seekTo(pos, MediaPlayer.SEEK_CLOSEST); m.start() }
        } catch (e: Exception) { Ui.status = "Playback error: ${e.javaClass.simpleName}" }
    } }
    fun applyOutput() { h.post { mp?.setPreferredDevice(outputDevice(ctx)) } }
    fun setGain(l: Float, r: Float) { gainL = l; gainR = r; h.post { mp?.setVolume(l, r) } }
    fun pause() { h.post { h.removeCallbacksAndMessages(null); mp?.pause() } }
    fun release() { h.post { h.removeCallbacksAndMessages(null); mp?.release(); mp = null; Fx.release() } }
}

class Host(val ctx: Context, val player: SyncPlayer) {
    private val peers = CopyOnWriteArrayList<Peer>()
    private var server: ServerSocket? = null
    private var reg: NsdManager.RegistrationListener? = null
    private val udp = DatagramSocket().apply { if (Cfg.dscp) trafficClass = 0xB8 } // DSCP EF -> Wi-Fi "voice" queue = lower latency
    private val pkt = ByteArray(4 + MAXPKT)
    @Volatile var pktSize = FRAME
    private var seq = 0
    @Volatile private var alive = true
    @Volatile var cfg: Pair<Int, Int>? = null
    @Volatile var cur: Song? = null
    @Volatile var startAt = 0L
    @Volatile var playing = false
    @Volatile var pausedPos = 0L
    @Volatile var pin = ""
    @Volatile var partyName = ""
    private var volObs: ContentObserver? = null
    private var lastV = -1f
    var queue = listOf<Song>()
    var idx = -1

    // Android forbids network I/O on the UI thread (volume observer, buttons, notification actions all run there),
    // so anything called from the main thread is handed to a background worker.
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    private fun bc(f: DataOutputStream.() -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) io.execute { peers.forEach { it.send(f) } }
        else peers.forEach { it.send(f) }
    }
    private fun info() { Ui.listeners = peers.size; Ui.status = "Hosting at ${localIp()}:$PORT" }
    fun listeners(): List<Peer> = peers.toList()
    fun kick(p: Peer) { io.execute { p.close() } }
    fun setGain(p: Peer, g: Float) { p.gain = g; io.execute { p.send { writeByte(13); writeFloat(g) } } }
    fun mute(p: Peer, m: Boolean) { p.muted = m; io.execute { p.send { writeByte(10); writeByte(if (m) 1 else 0) } } }
    private fun volFrac(): Float { val am = ctx.getSystemService(AudioManager::class.java)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    /** Sends the host's media volume (0..1) to every listener, if "Sync volume" is on. */
    fun pushVolume() { if (Ui.syncVol) { val v = volFrac(); bc { writeByte(9); writeFloat(v) } } }
    fun pos() = if (playing) now() - startAt else pausedPos

    fun start() {
        val ss = ServerSocket(PORT); server = ss
        val rl = object : NsdManager.RegistrationListener {
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
        }
        reg = rl
        ctx.getSystemService(NsdManager::class.java).registerService(
            NsdServiceInfo().apply { serviceName = "PartySync"; serviceType = SVC; port = PORT }, NsdManager.PROTOCOL_DNS_SD, rl)
        info()
        try { ctx.registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)) } catch (_: Exception) {}
        // Physical volume buttons change the system volume -> this observer fires (works with screen off too)
        volObs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(self: Boolean) { val v = volFrac(); if (v != lastV) { lastV = v; pushVolume() } }
        }.also { ctx.contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, it) }
        thread { while (alive) {
            val s = try { ss.accept() } catch (e: Exception) { break }
            s.tcpNoDelay = true; s.keepAlive = true; s.soTimeout = 8000 // dead listeners are dropped after 8 s
            thread { serve(Peer(s)) }
        } }
        thread { var t = 0; while (alive) { // resync every 3 s + auto-advance the queue
            Thread.sleep(500)
            val c = cur
            if (playing && c != null) {
                if (c.dur > 0 && now() - startAt >= c.dur - 300) { autoNext(); continue }
                if (++t % (Cfg.resyncSec * 2) == 0) { bc { writeByte(4); writeLong(c.id); writeLong(startAt) }; pushState() }
            }
        } }
    }

    private fun serve(p: Peer) {
        try {
            val first = p.inp.readUTF()
            if (first == INFO_Q) { p.send { writeByte(11); writeUTF(partyName.ifEmpty { Build.MODEL }); writeByte(if (pin.isEmpty()) 0 else 1) }; return }
            if (first != pin) { Ui.status = "Rejected ${p.sock.inetAddress.hostAddress}: wrong PIN"; p.send { writeByte(8) }; return }
            p.udpPort = p.inp.readInt(); p.name = p.inp.readUTF()
            if (Cfg.maxListeners > 0 && peers.size >= Cfg.maxListeners) { p.send { writeByte(12) }; return }
            peers.add(p); info()
            if (Ui.syncVol) { val v = volFrac(); p.send { writeByte(9); writeFloat(v) } }
            cfg?.let { c -> p.send { writeByte(6); writeInt(c.first); writeInt(c.second); writeInt(pktSize) } }
            cur?.let { c ->
                sendFile(c, listOf(p))
                if (playing) p.send { writeByte(4); writeLong(c.id); writeLong(startAt) }
            }
            pushState(p)
            while (true) when (p.inp.readByte().toInt()) {
                0 -> { val t0 = p.inp.readLong(); p.send { writeByte(1); writeLong(t0); writeLong(now()) } }
                20 -> { val cmd = p.inp.readByte().toInt(); val arg = p.inp.readLong(); remote(cmd, arg) } // listener remote control
            }
        } catch (_: Exception) {
        } finally { peers.remove(p); p.close(); if (alive) info() }
    }

    private fun sendFile(s: Song, to: List<Peer>) {
        val t = to.filter { s.id !in it.have }; if (t.isEmpty()) return
        t.forEach { it.send { writeByte(2); writeLong(s.id); writeLong(s.size); writeUTF(s.title) } }
        var sent = 0L
        ctx.contentResolver.openInputStream(s.uri)?.use { i ->
            val b = ByteArray(65536)
            while (true) {
                val n = i.read(b); if (n < 0) break
                t.forEach { it.send { writeByte(3); writeInt(n); write(b, 0, n) } }
                sent += n; Ui.status = "Uploading ${s.title}: ${sent * 100 / s.size.coerceAtLeast(1)}%"
            }
        }
        t.forEach { it.have.add(s.id) }
        info()
    }

    @Volatile var shuffle = false
    @Volatile var repeatMode = if (Cfg.repeatQueue) 1 else 0   // 0 off, 1 all, 2 one
    @Volatile var onState: (() -> Unit)? = null                // lets the notification / media session follow
    @Volatile var captureStop: (() -> Unit)? = null
    var baseQueue = listOf<Song>()
    private val am = ctx.getSystemService(AudioManager::class.java)
    private var focusReq: AudioFocusRequest? = null
    private var resumeOnFocus = false
    private val noisy = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { if (playing) pause() } } // headphones unplugged

    /** Native-player behaviour: pause for calls / other media apps, resume afterwards. */
    private fun requestFocus() {
        if (focusReq != null) return
        val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener { ch -> when (ch) {
                AudioManager.AUDIOFOCUS_LOSS -> { resumeOnFocus = false; if (playing) pause() }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> if (playing) { resumeOnFocus = true; pause() }
                AudioManager.AUDIOFOCUS_GAIN -> if (resumeOnFocus) { resumeOnFocus = false; resume() }
                else -> {} } }.build()
        if (am.requestAudioFocus(r) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) focusReq = r
    }
    private fun abandonFocus() { focusReq?.let { am.abandonAudioFocusRequest(it) }; focusReq = null }

    fun playSong(s: Song) { thread {
        playing = false
        captureStop?.invoke(); captureStop = null; cfg = null // local music replaces live system audio
        sendFile(s, peers.toList())
        cur = s; Ui.title = s.title; startAt = now() + Cfg.startLead; playing = true
        bc { writeByte(4); writeLong(s.id); writeLong(startAt) }
        requestFocus(); player.play(s.uri, startAt); pushState(); onState?.invoke()
    } }
    fun playQueue(l: List<Song>, i: Int) {
        val s = l.getOrNull(i) ?: return
        baseQueue = l; queue = if (shuffle) listOf(s) + (l - s).shuffled() else l; idx = if (shuffle) 0 else i
        playSong(s)
    }
    fun playAt(i: Int) { idx = i; queue.getOrNull(i)?.let { playSong(it) } }
    fun next() { if (queue.isNotEmpty()) playAt((idx + 1) % queue.size) }
    fun prev() { if (cur != null && pos() > 3000) seekTo(0) else if (queue.isNotEmpty()) playAt((idx - 1 + queue.size) % queue.size) }
    fun autoNext() { val c = cur ?: return
        if (repeatMode == 2) playSong(c) else if (repeatMode == 0 && idx + 1 >= queue.size) pause() else next() }
    fun shuffleMode(on: Boolean) { shuffle = on; val c = cur
        if (c != null && baseQueue.isNotEmpty()) { queue = if (on) listOf(c) + (baseQueue - c).shuffled() else baseQueue; idx = queue.indexOf(c).coerceAtLeast(0) }
        onState?.invoke() }
    fun cycleRepeat() { repeatMode = (repeatMode + 1) % 3; onState?.invoke() }
    fun addNext(s: Song) { queue = queue.toMutableList().also { it.add((idx + 1).coerceAtMost(it.size), s) }; baseQueue = baseQueue + s }
    fun addToQueue(s: Song) { queue = queue + s; baseQueue = baseQueue + s }
    fun seekBy(ms: Long) {
        val c = cur ?: return
        if (!playing) { pausedPos = (pausedPos + ms).coerceIn(0L, c.dur); pushState(); onState?.invoke(); return }
        startAt = now() - (now() - startAt + ms).coerceIn(0L, c.dur)
        bc { writeByte(4); writeLong(c.id); writeLong(startAt) }; player.play(c.uri, startAt); pushState(); onState?.invoke()
    }
    fun seekTo(ms: Long) = seekBy(ms - pos())
    fun pause() {
        if (!playing) return // a second pause (media-session, headset) must not corrupt the saved position
        playing = false; pausedPos = (now() - startAt).coerceAtLeast(0); bc { writeByte(5) }; player.pause(); pushState(); onState?.invoke()
    }
    fun resume() {
        val c = cur ?: return
        if (playing) return
        if (cfg != null) { playSong(c); return } // live system audio was on: "play" switches back to this local song
        val from = if (c.dur > 0 && pausedPos >= c.dur - 500) 0L else pausedPos // paused at the very end -> restart the song
        startAt = now() + minOf(800, Cfg.startLead) - from; playing = true
        bc { writeByte(4); writeLong(c.id); writeLong(startAt) }; requestFocus(); player.play(c.uri, startAt); pushState(); onState?.invoke()
    }
    fun toggle() { if (playing) pause() else resume() }

    /** The system-audio capture ended (user tapped "stop sharing"): leave live mode so listeners and UI don't hang on it. */
    fun endLive() { if (cfg == null) return; cfg = null; captureStop = null; Ui.title = cur?.title ?: ""; Ui.status = "Hosting at ${localIp()}:$PORT"; pushState(); onState?.invoke() }

    /** Listener-side player controls, can be switched off by the host. Sent to listeners inside STATE. */
    fun setClientControl(on: Boolean) {
        if (Cfg.clientCtl == on) return
        Cfg.clientCtl = on; Cfg.save(ctx); pushState(); onState?.invoke()
    }
    /** Commands from a listener: 1 play, 2 pause, 3 next, 4 prev, 5 seek by +-ms, 6 seek to ms. Ignored when the host disabled it or live audio is on. */
    private fun remote(cmd: Int, arg: Long) {
        if (!Cfg.clientCtl || cfg != null || cur == null) return
        when (cmd) {
            1 -> resume(); 2 -> pause(); 3 -> next(); 4 -> prev()
            5 -> seekBy(arg.coerceIn(-600000L, 600000L)); 6 -> seekTo(arg)
        }
    }
    /** STATE (14): flags(1 playing, 2 live, 4 control allowed, 8 has track), duration, startAt-or-pausedPos, title, artist. */
    fun pushState(only: Peer? = null) {
        val c = cur; val live = cfg != null
        val fl = (if (playing && !live) 1 else 0) or (if (live) 2 else 0) or (if (Cfg.clientCtl) 4 else 0) or (if (c != null && !live) 8 else 0)
        val dur = c?.dur ?: 0L; val base = if (playing) startAt else pausedPos
        val t = c?.title ?: ""; val a = c?.artist ?: ""
        val f: DataOutputStream.() -> Unit = { writeByte(14); writeByte(fl); writeLong(dur); writeLong(base); writeUTF(t); writeUTF(a) }
        if (only != null) only.send(f) else bc(f)
    }

    fun setPcm(rate: Int, ch: Int, pb: Int = FRAME) { cfg = rate to ch; pktSize = pb; Ui.title = "System audio"; bc { writeByte(6); writeInt(rate); writeInt(ch); writeInt(pb) }; pushState() }
    /** Live audio goes out as fire-and-forget UDP: no head-of-line blocking, one slow phone can't stall the rest. */
    fun sendPcm(b: ByteArray, n: Int) {
        seq++
        pkt[0] = (seq ushr 24).toByte(); pkt[1] = (seq ushr 16).toByte(); pkt[2] = (seq ushr 8).toByte(); pkt[3] = seq.toByte()
        System.arraycopy(b, 0, pkt, 4, n)
        for (p in peers) if (p.udpPort != 0) try { // reuse one packet object per listener: no allocation/GC in the audio path
            val d = p.dp ?: DatagramPacket(pkt, pkt.size, p.sock.inetAddress, p.udpPort).also { p.dp = it }
            d.length = 4 + n; udp.send(d)
        } catch (_: IOException) {}
    }

    fun stop() {
        alive = false
        try { server?.close() } catch (_: Exception) {}
        peers.forEach { it.close() }; udp.close(); io.shutdown(); onState = null
        abandonFocus(); try { ctx.unregisterReceiver(noisy) } catch (_: Exception) {}
        volObs?.let { ctx.contentResolver.unregisterContentObserver(it) }
        try { reg?.let { ctx.getSystemService(NsdManager::class.java).unregisterService(it) } } catch (_: Exception) {}
        player.release(); Ui.listeners = 0
    }
}

class Client(val ctx: Context, val player: SyncPlayer, val pin: String = "") {
    @Volatile var offset = 0L // hostClock - localClock
    @Volatile var hostVol = -1f
    @Volatile var muted = false
    @Volatile var gain = 1f // per-listener volume set by the host (0..1)
    @Volatile var ch = 0 // 0 = both, 1 = left only, 2 = right only
    @Volatile var pktBytes = FRAME   // packet size the host is using right now
    /** Cfg buffer sizes are counted in 2.5 ms packets; convert to packets of the host's current size. */
    private fun k(ref: Int) = maxOf(1, (ref * FRAME + pktBytes / 2) / pktBytes)
    @Volatile private var target = k(Cfg.init) // adaptive jitter buffer in packets
    @Volatile private var burstFrames = 192
    @Volatile var trim = Cfg.trimMs   // + = play earlier (compensates slow speakers/Bluetooth)
    @Volatile private var stopped = false
    @Volatile private var track: AudioTrack? = null
    @Volatile private var lastSeq = 0
    private var peer: Peer? = null
    // Host player state (STATE message) so the listener can show a controller
    @Volatile var rHas = false; @Volatile var rPlaying = false; @Volatile var rLive = false; @Volatile var rCtl = false
    @Volatile var rDur = 0L; @Volatile var rBase = 0L
    @Volatile var rTitle = ""; @Volatile var rArtist = ""
    /** Host's current playback position, extrapolated with the synced clock. */
    fun rPos(): Long = if (!rHas) 0L else if (rPlaying) (now() + offset - rBase).coerceIn(0L, rDur.coerceAtLeast(0L)) else rBase.coerceIn(0L, rDur.coerceAtLeast(0L))
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor() // socket writes must stay off the UI thread
    /** Remote control: 1 play, 2 pause, 3 next, 4 prev, 5 seek by ms, 6 seek to ms. The host decides whether to obey. */
    fun command(cmd: Int, arg: Long = 0L) { if (!rCtl || rLive) return
        try { io.execute { peer?.send { writeByte(20); writeByte(cmd); writeLong(arg) } } } catch (_: Exception) {} }
    private val q = LinkedBlockingQueue<ByteArray>()
    private val titles = HashMap<Long, String>()
    private fun file(id: Long) = File(ctx.cacheDir, "party_$id")

    fun connect(ip: String) { thread { var fails = 0; while (!stopped) {
        var udp: DatagramSocket? = null
        try {
            val s = Socket(); s.connect(InetSocketAddress(ip, PORT), 3000)
            s.tcpNoDelay = true; s.keepAlive = true; s.soTimeout = 6000 // no host traffic for 6 s -> reconnect
            val u = DatagramSocket().apply { if (Cfg.dscp) trafficClass = 0xB8 }; udp = u
            val p = Peer(s); peer = p; fails = 0; lastSeq = 0; q.clear()
            Ui.status = "Connected to $ip"
            p.send { writeUTF(pin); writeInt(u.localPort); writeUTF(Build.MODEL) }
            thread { udpRx(u) }; thread { playLoop(u) }
            thread { var i = 0; while (!s.isClosed) {
                val t = now(); p.send { writeByte(0); writeLong(t) }
                Thread.sleep(if (i++ < 8) 500 else 2000)
            } }
            val d = p.inp
            var out: OutputStream? = null; var left = 0L; var id = 0L; var best = Long.MAX_VALUE / 2
            val ready = HashSet<Long>()
            while (true) when (d.readByte().toInt()) {
                1 -> { // NTP-style clock sync, trusting the lowest-RTT samples
                    val t0 = d.readLong(); val h = d.readLong(); val t1 = now(); val rtt = t1 - t0
                    best = minOf(best + 1, rtt)
                    if (rtt <= best + 4) offset = h - (t0 + t1) / 2
                }
                2 -> { out?.close(); id = d.readLong(); left = d.readLong(); titles[id] = d.readUTF(); out = FileOutputStream(file(id)); Ui.status = "Receiving: ${titles[id]}" }
                3 -> {
                    val n = d.readInt(); val b = ByteArray(n); d.readFully(b)
                    out?.write(b); left -= n
                    if (left <= 0) { out?.close(); out = null; ready.add(id); Ui.status = "Song ready" }
                }
                4 -> { val sid = d.readLong(); val at = d.readLong()
                    if (sid in ready) { player.play(Uri.fromFile(file(sid)), at - offset - trim); Ui.title = titles[sid] ?: ""; Ui.status = "Playing in sync (trim $trim ms)" } }
                5 -> player.pause()
                6 -> { val rt = d.readInt(); val chn = d.readInt(); pktBytes = d.readInt().coerceIn(4, MAXPKT) and 3.inv(); target = k(Cfg.init); startTrack(rt, chn); Ui.title = "System audio"; Ui.status = "Streaming live" }
                14 -> { val fl = d.readByte().toInt(); val du = d.readLong(); val ba = d.readLong(); val ti = d.readUTF(); val ar = d.readUTF()
                    rPlaying = fl and 1 != 0; rLive = fl and 2 != 0; rCtl = fl and 4 != 0; rHas = fl and 8 != 0
                    rDur = du; rBase = ba; rTitle = ti; rArtist = ar }
                13 -> { gain = d.readFloat(); applyGain() }
                10 -> { muted = d.readByte().toInt() == 1; applyGain() }
                9 -> { hostVol = d.readFloat(); if (Ui.syncVol) applyVol() }
                12 -> { stopped = true; Ui.status = "Party is full"; s.close() }
                8 -> { stopped = true; Ui.status = "Wrong PIN"; s.close() }
            }
        } catch (e: Exception) { rCtl = false; if (!stopped) Ui.status = "Can't reach $ip:$PORT (${e.javaClass.simpleName}) — retrying" }
        finally { udp?.close() }
        if (!Cfg.autoReconnect) { stopped = true; continue }
        if (!stopped) Thread.sleep(minOf(1000L shl minOf(fails++, 3), 5000L))
    } } }

    fun setChannel(c: Int) { ch = c; applyGain() }
    fun applyMode() { target = k(Cfg.init) }
    fun applyOutput() { track?.setPreferredDevice(outputDevice(ctx)); player.applyOutput() }
    fun diag() = "Clock offset $offset ms · jitter buffer ${target * pktBytes / 192} ms (${pktBytes} B packets) (queued ${q.size}) · trim $trim ms"
    private fun applyGain() { val m = if (muted) 0f else gain; player.setGain(if (ch == 2) 0f else m, if (ch == 1) 0f else m) }

    /** Mirrors the host's volume onto this phone's media volume. */
    fun applyVol() { if (hostVol < 0) return; try {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(hostVol * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)), 0)
    } catch (_: Exception) {} }

    private fun udpRx(u: DatagramSocket) {
        val buf = ByteArray(4 + MAXPKT + 64); val dp = DatagramPacket(buf, buf.size)
        while (!u.isClosed) {
            dp.length = buf.size // receive() shrinks the length to the last packet; reset or bigger packets get truncated
            try { u.receive(dp) } catch (e: IOException) { break }
            if (dp.length <= 4) continue
            val sq = ((buf[0].toInt() and 255) shl 24) or ((buf[1].toInt() and 255) shl 16) or ((buf[2].toInt() and 255) shl 8) or (buf[3].toInt() and 255)
            if (lastSeq != 0 && sq <= lastSeq) continue                       // late or duplicate
            if (lastSeq != 0) repeat(minOf(sq - lastSeq - 1, Cfg.conceal)) { q.offer(ByteArray(pktBytes)) } // conceal loss with silence
            lastSeq = sq; q.offer(buf.copyOfRange(4, dp.length))
            if (q.size > k(Cfg.max) + k(16)) while (q.size > target) q.poll()                 // never let delay build up past ~120 ms
        }
    }

    private fun playLoop(u: DatagramSocket) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        var primed = false; var lastAdj = now(); var lastU = 0
        while (!u.isClosed) {
            val t = track
            if (t == null) { Thread.sleep(20); continue }
            if (!primed) { if (q.size < target) { Thread.sleep(2); continue }; primed = true } // 40 ms jitter buffer
            val b = q.poll(50, TimeUnit.MILLISECONDS)
            if (b == null) { primed = false; if (Cfg.adaptive) target = minOf(target + k(4), k(Cfg.max)); lastAdj = now(); continue } // Wi-Fi hiccup: grow buffer                       // underrun: rebuffer
            if (muted) java.util.Arrays.fill(b, 0)
            else if (ch != 0) { var i = if (ch == 2) 0 else 2; while (i + 1 < b.size) { b[i] = 0; b[i + 1] = 0; i += 4 } } // stereo split
            if (!muted && gain < 0.99f) { var i = 0; while (i + 1 < b.size) { // software per-listener volume
                val v = ((b[i].toInt() and 255) or (b[i + 1].toInt() shl 8)).toShort(); val x = (v * gain).toInt()
                b[i] = x.toByte(); b[i + 1] = (x shr 8).toByte(); i += 2 } }
            t.write(b, 0, b.size)
            val u = t.underrunCount // hardware buffer starved -> give it one more burst, up to 6
            if (u != lastU) { lastU = u; t.bufferSizeInFrames = minOf(t.bufferSizeInFrames + burstFrames, burstFrames * 6) }
            if (now() - lastAdj > 3000) { if (Cfg.adaptive) target = maxOf(k(Cfg.min), target - 1); lastAdj = now() } // calm Wi-Fi: shrink buffer
        }
    }

    private fun startTrack(rate: Int, ch: Int) {
        track?.release(); q.clear()
        val mask = if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val min = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask).build())
            .setBufferSizeInBytes(maxOf(min, pktBytes * 3)).setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build().also { t ->
                // shrink the output buffer to 2 hardware bursts (a few ms) instead of the default multi-burst size
                burstFrames = ctx.getSystemService(AudioManager::class.java).getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 192
                t.bufferSizeInFrames = burstFrames * Cfg.outBursts
                outputDevice(ctx)?.let { d -> t.setPreferredDevice(d) }; Fx.attach(t.audioSessionId); t.play() }
    }

    fun stop() { stopped = true; peer?.close(); track?.release(); player.release(); io.shutdown()
        ctx.cacheDir.listFiles()?.filter { it.name.startsWith("party_") }?.forEach { it.delete() } }
}

/** Finds hosts two ways: mDNS (instant, but many routers/hotspots block it) and a subnet scan (works whenever TCP works). */
class Discovery(ctx: Context, val onFound: (String, String, Boolean) -> Unit) {
    private val nsd = ctx.getSystemService(NsdManager::class.java)
    private val mlock = ctx.applicationContext.getSystemService(WifiManager::class.java).createMulticastLock("party:mdns")
    private val pending = java.util.ArrayDeque<NsdServiceInfo>()
    private var busy = false

    @Synchronized private fun next() {
        if (busy) return
        val i = pending.poll() ?: return
        busy = true
        nsd.resolveService(i, object : NsdManager.ResolveListener { // one resolve at a time, or Android rejects the rest
            override fun onResolveFailed(i: NsdServiceInfo, e: Int) { done() }
            override fun onServiceResolved(r: NsdServiceInfo) { r.host?.hostAddress?.let { thread { query(it, 1500) } }; done() }
        })
    }
    @Synchronized private fun done() { busy = false; next() }

    private val l = object : NsdManager.DiscoveryListener {
        override fun onServiceFound(i: NsdServiceInfo) { synchronized(this@Discovery) { pending.add(i) }; next() }
        override fun onServiceLost(i: NsdServiceInfo) {}
        override fun onDiscoveryStarted(t: String) {}
        override fun onDiscoveryStopped(t: String) {}
        override fun onStartDiscoveryFailed(t: String, e: Int) {}
        override fun onStopDiscoveryFailed(t: String, e: Int) {}
    }

    private fun query(ip: String, t: Int) { try { Socket().use { s ->
        s.connect(InetSocketAddress(ip, PORT), t); s.soTimeout = 1500
        val o = DataOutputStream(s.getOutputStream()); o.writeUTF(INFO_Q); o.flush()
        val d = DataInputStream(s.getInputStream())
        if (d.readByte().toInt() == 11) onFound(ip, d.readUTF(), d.readByte().toInt() == 1)
    } } catch (_: Exception) {} }

    private fun scan() { thread {
        val me = localIp(); if (me == "?") return@thread
        val base = me.substringBeforeLast('.') + "."
        val pool = java.util.concurrent.Executors.newFixedThreadPool(48)
        for (n in 1..254) { val ip = base + n; if (ip == me) continue
            pool.execute { query(ip, 400) } }
        pool.shutdown()
    } }

    fun start() { try { mlock.acquire() } catch (_: Exception) {}
        try { nsd.discoverServices(SVC, NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) {}
        scan() }
    fun stop() { try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {}
        try { if (mlock.isHeld) mlock.release() } catch (_: Exception) {} }
}

/** All user-tunable options (Settings tab), persisted in SharedPreferences. */
object Cfg {
    @Volatile var mode = 1                 // 0 ultra-low, 1 balanced, 2 stable (jitter buffer limits)
    @Volatile var adaptive = true
    @Volatile var autoReconnect = true
    @Volatile var keepAwake = true
    @Volatile var wifiPin = true
    @Volatile var dscp = true
    @Volatile var capMedia = true; @Volatile var capGame = true; @Volatile var capOther = true
    @Volatile var repeatQueue = true
    @Volatile var clientCtl = true         // host lets listeners play / pause / seek / skip
    @Volatile var maxListeners = 0         // 0 = unlimited
    @Volatile var eqOn = false; val eqLv = IntArray(5) // equalizer on/off + 5 band levels (millibels)
    @Volatile var bass = 0; @Volatile var spatial = 0  // 0..1000
    @Volatile var outDev = 0               // AudioDeviceInfo id, 0 = automatic
    // Advanced latency options (0 = follow the preset above)
    @Volatile var bufInit = 0; @Volatile var bufMin = 0; @Volatile var bufMax = 0   // jitter buffer, ms
    @Volatile var outBursts = 2            // AudioTrack buffer = this many hardware bursts (1..6)
    @Volatile var drift = 60               // re-seek local player when off by more than this many ms
    @Volatile var conceal = 4              // max lost packets replaced with silence per gap
    @Volatile var trimMs = 0L              // saved listener latency trim
    @Volatile var startLead = 1500         // host: ms between "play" and the synchronized start
    @Volatile var resyncSec = 3            // host: how often position is re-broadcast
    @Volatile var pktBytes = FRAME         // host: PCM bytes per UDP packet (smaller = lower delay, more packets)
    private fun pk(ms: Int) = (ms * 2 / 5).coerceAtLeast(1)   // ms -> packets of 2.5 ms
    val init get() = if (bufInit > 0) pk(bufInit) else intArrayOf(6, 8, 16)[mode]
    val min get() = minOf(if (bufMin > 0) pk(bufMin) else intArrayOf(3, 4, 8)[mode], init)
    val max get() = maxOf(if (bufMax > 0) pk(bufMax) else intArrayOf(24, 32, 48)[mode], init)
    fun resetLatency() { bufInit = 0; bufMin = 0; bufMax = 0; outBursts = 2; drift = 60; conceal = 4; trimMs = 0L; startLead = 1500; resyncSec = 3; pktBytes = FRAME }
    fun load(c: Context) { val s = c.getSharedPreferences("cfg", 0)
        mode = s.getInt("mode", 1); adaptive = s.getBoolean("adaptive", true); autoReconnect = s.getBoolean("rc", true)
        keepAwake = s.getBoolean("awake", true); wifiPin = s.getBoolean("pin", true); dscp = s.getBoolean("dscp", true)
        capMedia = s.getBoolean("cm", true); capGame = s.getBoolean("cg", true); capOther = s.getBoolean("co", true)
        repeatQueue = s.getBoolean("rep", true); clientCtl = s.getBoolean("cc", true); maxListeners = s.getInt("max", 0); Ui.syncVol = s.getBoolean("vol", true)
        eqOn = s.getBoolean("eq", false); (s.getString("eqv", "0,0,0,0,0") ?: "").split(",").forEachIndexed { i, v -> if (i < 5) eqLv[i] = v.toIntOrNull() ?: 0 }
        bass = s.getInt("bass", 0); spatial = s.getInt("spat", 0); outDev = s.getInt("out", 0)
        bufInit = s.getInt("bi", 0); bufMin = s.getInt("bmin", 0); bufMax = s.getInt("bmax", 0); outBursts = s.getInt("ob", 2).coerceIn(1, 6)
        drift = s.getInt("dr", 60); conceal = s.getInt("cn", 4); trimMs = s.getLong("tr", 0L); startLead = s.getInt("sl", 1500); resyncSec = s.getInt("rs", 3).coerceIn(1, 10)
        pktBytes = s.getInt("pk", FRAME).let { if (it in PKT_SIZES) it else FRAME } }
    fun save(c: Context) { c.getSharedPreferences("cfg", 0).edit().putInt("mode", mode).putBoolean("adaptive", adaptive)
        .putBoolean("rc", autoReconnect).putBoolean("awake", keepAwake).putBoolean("pin", wifiPin).putBoolean("dscp", dscp)
        .putBoolean("cm", capMedia).putBoolean("cg", capGame).putBoolean("co", capOther).putBoolean("rep", repeatQueue).putBoolean("cc", clientCtl)
        .putInt("max", maxListeners).putBoolean("vol", Ui.syncVol)
        .putBoolean("eq", eqOn).putString("eqv", eqLv.joinToString(",")).putInt("bass", bass).putInt("spat", spatial).putInt("out", outDev)
        .putInt("bi", bufInit).putInt("bmin", bufMin).putInt("bmax", bufMax).putInt("ob", outBursts).putInt("dr", drift).putInt("cn", conceal)
        .putLong("tr", trimMs).putInt("sl", startLead).putInt("rs", resyncSec).putInt("pk", pktBytes).apply() }
    fun reset(c: Context) { mode = 1; adaptive = true; autoReconnect = true; keepAwake = true; wifiPin = true; dscp = true
        capMedia = true; capGame = true; capOther = true; repeatQueue = true; clientCtl = true; maxListeners = 0; Ui.syncVol = true
        eqOn = false; eqLv.fill(0); bass = 0; spatial = 0; outDev = 0; resetLatency(); save(c) }
}

fun outputDevice(ctx: Context): AudioDeviceInfo? = if (Cfg.outDev == 0) null else
    ctx.getSystemService(AudioManager::class.java).getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.id == Cfg.outDev }

/** Equalizer / bass boost / 3D virtualizer, attached to whichever player is active (AudioTrack or MediaPlayer). */
object Fx {
    private var eq: Equalizer? = null; private var bass: BassBoost? = null; private var virt: Virtualizer? = null
    private var sess = 0
    private fun wanted() = Cfg.eqOn || Cfg.bass > 0 || Cfg.spatial > 0
    private fun drop() { try { eq?.release(); bass?.release(); virt?.release() } catch (_: Exception) {}; eq = null; bass = null; virt = null }
    private fun create(session: Int) {
        try { eq = Equalizer(0, session) } catch (_: Exception) {}
        try { bass = BassBoost(0, session) } catch (_: Exception) {}
        try { virt = Virtualizer(0, session) } catch (_: Exception) {}
    }
    /** Effects are only created while one is switched on, so a plain song never goes through an effect chain. */
    @Synchronized fun attach(session: Int) { drop(); sess = session; if (session != 0 && wanted()) create(session); applyAll() }
    @Synchronized fun release() { drop(); sess = 0 }
    @Synchronized fun refresh() { if (eq == null && bass == null && virt == null && sess != 0 && wanted()) create(sess); applyAll() }
    private fun applyAll() {
        try { eq?.let { e -> e.setEnabled(Cfg.eqOn); val r = e.bandLevelRange
            for (b in 0 until minOf(5, e.numberOfBands.toInt())) e.setBandLevel(b.toShort(), Cfg.eqLv[b].coerceIn(r[0].toInt(), r[1].toInt()).toShort()) } } catch (_: Exception) {}
        try { bass?.let { it.setEnabled(Cfg.bass > 0); if (it.strengthSupported) it.setStrength(Cfg.bass.toShort()) } } catch (_: Exception) {}
        try { virt?.let { it.setEnabled(Cfg.spatial > 0); if (it.strengthSupported) it.setStrength(Cfg.spatial.toShort()) } } catch (_: Exception) {}
    }
}
