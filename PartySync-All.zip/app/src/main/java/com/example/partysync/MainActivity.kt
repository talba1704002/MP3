package com.example.partysync

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val BG = 0xFF0F1115.toInt(); private val CARD = 0xFF1A1D24.toInt()
    private val ACC = 0xFF6C8CFF.toInt(); private val TXT = 0xFFE8EAF0.toInt()
    private lateinit var statusTv: TextView; private lateinit var titleTv: TextView
    private lateinit var timeTv: TextView; private lateinit var bandTv: TextView
    private lateinit var seek: SeekBar; private lateinit var ad: ArrayAdapter<String>
    private lateinit var pin: EditText; private lateinit var ip: EditText
    private lateinit var hostPanel: View; private lateinit var joinPanel: View; private lateinit var controls: View
    private lateinit var tabHost: Button; private lateinit var tabJoin: Button
    private val items = ArrayList<String>()
    private var onPick: (Int) -> Unit = {}
    private var songs = listOf<Song>()
    private var discovery: Discovery? = null
    private var drag = false

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun shape(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, sp: Float, c: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun btn(t: String, filled: Boolean = false, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(if (filled) Color.WHITE else TXT)
        background = shape(if (filled) ACC else CARD); setOnClickListener { f() } }
    private fun row(vararg v: View) = LinearLayout(this).apply {
        v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }) } }
    private fun col(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; v.forEach { addView(it) } }
    private fun fmt(ms: Long) = ms.coerceAtLeast(0).let { "%d:%02d".format(it / 60000, it / 1000 % 60) }
    private fun field(h: String) = EditText(this).apply { hint = h; setHintTextColor(0xFF7A8090.toInt()); setTextColor(TXT); background = shape(CARD); setPadding(dp(14), dp(10), dp(14), dp(10)) }

    private fun svc(mode: String, host: String? = null) = startForegroundService(
        Intent(this, PartyService::class.java).putExtra("mode", mode).putExtra("ip", host)
            .putExtra("pin", pin.text.toString().trim()))

    private fun show(l: List<String>) { items.clear(); items += l; ad.notifyDataSetChanged() }

    private fun setMode(host: Boolean) {
        hostPanel.visibility = if (host) View.VISIBLE else View.GONE
        joinPanel.visibility = if (host) View.GONE else View.VISIBLE
        controls.visibility = if (host) View.VISIBLE else View.GONE
        seek.visibility = controls.visibility; timeTv.visibility = controls.visibility
        tabHost.background = shape(if (host) ACC else CARD); tabJoin.background = shape(if (host) CARD else ACC)
        show(emptyList())
    }

    private fun updateBand() {
        val (name, ok) = wifiBand(this)
        bandTv.text = if (ok) "● $name" else "● $name — tap for 5 GHz"
        bandTv.setTextColor(if (ok) 0xFF4ADE80.toInt() else 0xFFFBBF24.toInt())
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += listOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else perms += Manifest.permission.READ_EXTERNAL_STORAGE
        requestPermissions(perms.toTypedArray(), 1)

        bandTv = tv("", 13f).apply { background = shape(CARD, 20); setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } }
        tabHost = btn("Host") { setMode(true) }; tabJoin = btn("Join") { setMode(false) }
        pin = field("Party PIN (optional)"); ip = field("Host IP (or tap Find hosts)")
        val syncSw = Switch(this).apply { text = "Sync volume with host buttons"; isChecked = true; setTextColor(TXT)
            setOnCheckedChangeListener { _, on -> Ui.syncVol = on; PartyService.host?.pushVolume(); if (on) PartyService.client?.applyVol() } }

        hostPanel = row(
            btn("🔊  System audio", true) {
                startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7) },
            btn("🎵  My music", true) {
                svc("host"); songs = scanSongs(this); show(songs.map { it.title }); onPick = { PartyService.host?.playQueue(songs, it) } },
            btn("👥") { listenersDialog() }, btn("📱") { inviteDialog() })
        joinPanel = col(ip, row(btn("🔈 L") { PartyService.client?.setChannel(1) }, btn("Both") { PartyService.client?.setChannel(0) },
            btn("R 🔈") { PartyService.client?.setChannel(2) }), row(
            btn("Find hosts") {
                val found = ArrayList<String>(); show(found); onPick = { svc("join", found[it]) }
                discovery?.stop()
                discovery = Discovery(this) { h -> runOnUiThread { if (h !in found) { found += h; show(found) } } }.also { it.start() }
                Ui.status = "Searching for hosts…" },
            btn("Connect", true) { val t = ip.text.toString().trim(); if (t.isNotEmpty()) svc("join", t) else Ui.status = "Enter the host IP" }),
            row(btn("◀ later") { PartyService.client?.let { it.trim -= 100; Ui.status = "Trim ${it.trim} ms" } },
                btn("earlier ▶") { PartyService.client?.let { it.trim += 100; Ui.status = "Trim ${it.trim} ms" } }))

        titleTv = tv("Nothing playing", 18f, TXT, true)
        timeTv = tv("0:00 / 0:00", 12f, 0xFF9AA0B0.toInt())
        statusTv = tv("Idle", 13f, 0xFF9AA0B0.toInt())
        seek = SeekBar(this).apply { setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar) { drag = true }
            override fun onStopTrackingTouch(s: SeekBar) { drag = false; PartyService.host?.let { it.seekBy(s.progress - it.pos()) } }
        }) }
        controls = row(btn("⏮") { PartyService.host?.prev() }, btn("⏪") { PartyService.host?.seekBy(-10000) },
            btn("⏯", true) { PartyService.host?.let { if (it.playing) it.pause() else it.resume() } },
            btn("⏩") { PartyService.host?.seekBy(10000) }, btn("⏭") { PartyService.host?.next() },
            btn("🔀") { PartyService.host?.playQueue(songs.shuffled(), 0) })
        val now = col(titleTv, seek, timeTv, controls, statusTv).apply { background = shape(CARD); setPadding(dp(14), dp(14), dp(14), dp(10)) }
        now.background = shape(0xFF20242E.toInt(), 18)

        ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        val list = ListView(this).apply { adapter = ad; divider = null; setOnItemClickListener { _, _, i, _ -> onPick(i) } }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            setOnApplyWindowInsetsListener { v, i -> @Suppress("DEPRECATION") v.setPadding(dp(16), i.systemWindowInsetTop + dp(12), dp(16), i.systemWindowInsetBottom + dp(12)); i } }
        root.addView(LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL
            addView(tv("Party Sync", 24f, TXT, true), LinearLayout.LayoutParams(0, -2, 1f)); addView(bandTv) })
        listOf(row(tabHost, tabJoin), pin, syncSw, hostPanel, joinPanel, now).forEach { root.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, -2).apply { topMargin = dp(8) }) }
        root.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        root.addView(btn("Stop") { discovery?.stop(); startService(Intent(this, PartyService::class.java).putExtra("mode", "stop")) })
        setContentView(root); setMode(true); updateBand(); handleLink(intent)

        ui.post(object : Runnable { var n = 0
            override fun run() {
                statusTv.text = Ui.status + if (Ui.listeners > 0) "  ·  ${Ui.listeners} listening" else ""
                titleTv.text = Ui.title.ifEmpty { "Nothing playing" }
                PartyService.host?.let { h -> val c = h.cur
                    if (c != null && !drag) { seek.max = c.dur.toInt(); seek.progress = h.pos().toInt().coerceIn(0, c.dur.toInt()); timeTv.text = "${fmt(h.pos())} / ${fmt(c.dur)}" } }
                if (n++ % 8 == 0) updateBand()
                ui.postDelayed(this, 400)
            } })
    }

    private fun listenersDialog() {
        val h = PartyService.host ?: return; val ps = h.listeners()
        if (ps.isEmpty()) { Ui.status = "No listeners yet"; return }
        AlertDialog.Builder(this).setTitle("Listeners").setItems(ps.map { it.name + if (it.muted) "  🔇" else "" }.toTypedArray()) { _, i ->
            AlertDialog.Builder(this).setItems(arrayOf(if (ps[i].muted) "Unmute" else "Mute", "Kick")) { _, k ->
                if (k == 0) h.mute(ps[i], !ps[i].muted) else h.kick(ps[i]) }.show() }.show()
    }

    private fun qr(text: String): Bitmap {
        val m = com.google.zxing.qrcode.QRCodeWriter().encode(text, com.google.zxing.BarcodeFormat.QR_CODE, 600, 600)
        val bmp = Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565)
        for (x in 0 until 600) for (y in 0 until 600) bmp.setPixel(x, y, if (m.get(x, y)) Color.BLACK else Color.WHITE)
        return bmp
    }

    private fun inviteDialog() {
        val link = "partysync://join?ip=${localIp()}&pin=${pin.text.toString().trim()}"
        val iv = ImageView(this).apply { setImageBitmap(qr(link)); setPadding(dp(16), dp(16), dp(16), dp(16)) }
        AlertDialog.Builder(this).setTitle("Scan with the phone camera to join").setView(iv)
            .setNeutralButton("Share link") { _, _ -> startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link), null)) }
            .setPositiveButton("Close", null).show()
    }

    private fun handleLink(i: Intent?) {
        val u = i?.data ?: return; if (u.scheme != "partysync") return
        val h = u.getQueryParameter("ip") ?: return
        pin.setText(u.getQueryParameter("pin") ?: ""); ip.setText(h); setMode(false); svc("join", h)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleLink(i) }

    @Deprecated("fine for a plain Activity")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 7 && res == RESULT_OK && data != null) startForegroundService(
            Intent(this, PartyService::class.java).putExtra("mode", "pcm").putExtra("code", res).putExtra("data", data)
                .putExtra("pin", pin.text.toString().trim()))
    }

    override fun onDestroy() { discovery?.stop(); ui.removeCallbacksAndMessages(null); super.onDestroy() }
}
