package com.example.partysync

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var ad: ArrayAdapter<String>
    private val items = ArrayList<String>()
    private var onPick: (Int) -> Unit = {}
    private var songs = listOf<Song>()
    private var discovery: Discovery? = null
    private lateinit var pin: EditText

    private fun svc(mode: String, ip: String? = null) = startForegroundService(
        Intent(this, PartyService::class.java).putExtra("mode", mode).putExtra("ip", ip)
            .putExtra("pin", pin.text.toString().trim()))

    private fun show(list: List<String>) { items.clear(); items += list; ad.notifyDataSetChanged() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += listOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else perms += Manifest.permission.READ_EXTERNAL_STORAGE
        requestPermissions(perms.toTypedArray(), 1)

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun row(vararg v: android.view.View) = LinearLayout(this).apply { v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) } }
        pin = EditText(this).apply { hint = "Party PIN (optional)" }
        status = TextView(this).apply { text = "Idle"; setPadding(24, 24, 24, 24) }
        val ip = EditText(this).apply { hint = "Host IP (leave empty to auto-discover)" }
        ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        val list = ListView(this).apply { adapter = ad; setOnItemClickListener { _, _, i, _ -> onPick(i) } }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        listOf(
            status,
            btn("Host: share system audio") {
                startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
            },
            btn("Host: share my music") {
                svc("host"); songs = scanSongs(this)
                show(songs.map { it.title }); onPick = { PartyService.host?.playQueue(songs, it) }
            },
            row(btn("⏮") { PartyService.host?.prev() }, btn("−10s") { PartyService.host?.seekBy(-10000) },
                btn("⏯") { PartyService.host?.let { if (it.playing) it.pause() else it.resume() } },
                btn("+10s") { PartyService.host?.seekBy(10000) }, btn("⏭") { PartyService.host?.next() }),
            btn("Shuffle all") { PartyService.host?.playQueue(songs.shuffled(), 0) },
            pin, ip,
            btn("Join party") {
                val t = ip.text.toString().trim()
                if (t.isNotEmpty()) svc("join", t) else {
                    val found = ArrayList<String>(); show(found)
                    onPick = { svc("join", found[it]) }
                    discovery?.stop()
                    discovery = Discovery(this) { h -> runOnUiThread { if (h !in found) { found += h; show(found) } } }.also { it.start() }
                    status.text = "Searching for hosts…"
                }
            },
            row(btn("◀ later") { PartyService.client?.let { it.trim -= 100; status.text = "Trim ${it.trim} ms" } },
                btn("earlier ▶") { PartyService.client?.let { it.trim += 100; status.text = "Trim ${it.trim} ms" } }),
            btn("Stop") { discovery?.stop(); startService(Intent(this, PartyService::class.java).putExtra("mode", "stop")); status.text = "Idle" }
        ).forEach { root.addView(it) }
        root.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
        PartyService.onLog = { status.text = it }
    }

    @Deprecated("fine for a plain Activity")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 7 && res == RESULT_OK && data != null) startForegroundService(
            Intent(this, PartyService::class.java).putExtra("mode", "pcm").putExtra("code", res).putExtra("data", data)
                .putExtra("pin", pin.text.toString().trim()))
    }

    override fun onDestroy() { discovery?.stop(); PartyService.onLog = null; super.onDestroy() }
}
