package com.example.partysync

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.RippleDrawable
import android.view.HapticFeedbackConstants
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.media.AudioDeviceInfo as AD
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import android.os.*
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** The vertical HOST / JOIN pill from the welcome screen: tap a half, the knob slides there, then we navigate. */
class ModeSwitch(ctx: Context, private val onPick: (Boolean) -> Unit) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pos = 0f
    private var busy = false
    private val green = 0xFF3FA535.toInt(); private val blue = 0xFF4FC3F7.toInt()

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((110 * d).toInt(), (260 * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = w / 2
        p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = Color.WHITE
        c.drawRoundRect(3f, 3f, w - 3, h - 3, r, r, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 20 * d; p.typeface = Typeface.DEFAULT_BOLD
        p.color = 0xFF4CD137.toInt(); c.drawText("HOST", w / 2, r + 7 * d, p)
        p.color = blue; c.drawText("JOIN", w / 2, h - r + 7 * d, p)
        val cy = r + pos * (h - 2 * r)
        p.color = if (pos < 0.5f) green else blue; c.drawCircle(w / 2, cy, r - 6 * d, p)
        p.color = Color.BLACK; c.drawText(if (pos < 0.5f) "HOST" else "JOIN", w / 2, cy + 7 * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP && !busy) {
            busy = true; performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); val join = e.y > height / 2
            ValueAnimator.ofFloat(pos, if (join) 1f else 0f).apply {
                duration = 250
                addUpdateListener { pos = it.animatedValue as Float; invalidate() }
                addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { onPick(!join) } })
            }.start()
        }
        return true
    }
}

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val GREEN = 0xFF4CD137.toInt(); private val BLUE = 0xFF4FC3F7.toInt()
    private val WHITE = Color.WHITE; private val MUTED = 0xFF9AA0B0.toInt()

    private lateinit var frame: FrameLayout
    private lateinit var mainView: View
    private lateinit var tabContent: FrameLayout
    private lateinit var pages: List<View>
    private lateinit var navItems: List<TextView>
    private lateinit var hostBox: LinearLayout
    private lateinit var listenersBox: LinearLayout
    private lateinit var formStatus: TextView
    private lateinit var homeTitle: TextView; private lateinit var homeRole: TextView; private lateinit var homeStatus: TextView
    private lateinit var npTitle: TextView; private lateinit var npTime: TextView; private lateinit var trimTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var diagTv: TextView
    private lateinit var volSeek: SeekBar
    private lateinit var playBtn: Button
    private lateinit var addrTv: TextView
    private var lastTitle = ""
    private lateinit var devBtn: Button
    private val eqBars = ArrayList<SeekBar>()
    private lateinit var leaveBtn: Button
    private lateinit var songAd: ArrayAdapter<String>
    private val songItems = ArrayList<String>()
    private val bandChips = ArrayList<TextView>()
    private val hostViews = ArrayList<View>(); private val clientViews = ArrayList<View>()
    private val found = ArrayList<Triple<String, String, Boolean>>() // ip, name, locked
    private var screen = "welcome"
    private var isHost = true
    private var partyName = ""; private var partyPin = ""
    private var songs = listOf<Song>()
    private var discovery: Discovery? = null
    private var drag = false
    private var lSig = ""

    // ---------- small view helpers ----------
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, stroke: Int = 0, r: Int = 16) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(2), stroke) }
    private fun tv(t: String, sp: Float, c: Int = WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun pill(t: String, c: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(c); textSize = 15f; minHeight = dp(44); minimumHeight = dp(44)
        background = ripple(box(Color.TRANSPARENT, c, 24), 24); setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); f() } }
    private fun fill(t: String, c: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.BLACK); textSize = 15f; minHeight = dp(40); minimumHeight = dp(40)
        background = ripple(box(c, 0, 24), 24); setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); f() } }
    private fun field(h: String, c: Int, pw: Boolean = false) = EditText(this).apply {
        hint = h; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(WHITE); textSize = 15f
        if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        isSingleLine = true; background = box(Color.TRANSPARENT, c, 24); setPadding(dp(18), dp(12), dp(18), dp(12)) }
    private fun ripple(content: Drawable, r: Int): Drawable = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), content, box(Color.WHITE, 0, r))
    private fun bigCard(icon: String, title: String, sub: String, f: () -> Unit): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = ripple(box(0xFF14171D.toInt(), GREEN, 22), 22)
        addView(tv(icon, 30f))
        addView(col().also { c -> add(c, tv(title, 17f, WHITE, true), 0); add(c, tv(sub, 12f, MUTED), 2) }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); f() } }
    private fun col(pad: Int = 0) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)) }
    private fun row(vararg v: View) = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }) } }
    private fun add(p: LinearLayout, v: View, top: Int = 10) = p.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, -2).apply { topMargin = dp(top) })
    private fun fmt(ms: Long) = ms.coerceAtLeast(0).let { "%d:%02d".format(it / 60000, it / 1000 % 60) }
    private fun accent() = if (isHost) GREEN else BLUE
    private fun setScreen(name: String, v: View) { screen = name; frame.removeAllViews(); frame.addView(v)
        v.alpha = 0f; v.translationY = dp(16).toFloat(); v.animate().alpha(1f).translationY(0f).setDuration(220).start() }
    private fun centered(v: View): View = ScrollView(this).apply { isFillViewport = true
        addView(LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(v, LinearLayout.LayoutParams(MATCH_PARENT, -2)) }) }
    private fun panel(fill: Int, accent: Int, title: String, inner: LinearLayout, vararg extra: View): View {
        val p = col(18).apply { background = box(fill, WHITE, 26) }
        add(p, tv(title, 20f, accent).apply { gravity = Gravity.CENTER; background = box(Color.TRANSPARENT, WHITE, 24)
            setPadding(dp(14), dp(12), dp(14), dp(12)) }, 0)
        inner.background = box(Color.TRANSPARENT, WHITE, 22); inner.setPadding(dp(14), dp(14), dp(14), dp(14))
        add(p, inner, 22); extra.forEach { add(p, it, 10) }
        return centered(p)
    }
    private fun bandChip(): TextView = tv("", 13f).apply { background = box(Color.TRANSPARENT, MUTED, 20)
        setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } }.also { bandChips += it }
    private fun updateBand() { val (n, ok) = wifiBand(this)
        bandChips.forEach { it.text = if (ok) "● $n" else "● $n — tap for 5 GHz"; it.setTextColor(if (ok) GREEN else 0xFFFBBF24.toInt()) } }

    private fun svc(mode: String, host: String?, name: String, pinStr: String) {
        try {
            startForegroundService(Intent(this, PartyService::class.java).putExtra("mode", mode).putExtra("ip", host)
                .putExtra("name", name).putExtra("pin", pinStr))
        } catch (e: Exception) { Ui.status = "Can't start service: ${e.javaClass.simpleName}: ${e.message}" }
    }

    /** Checks the network path first and says exactly why it fails. */
    private fun probe(host: String, pinStr: String, onFail: () -> Unit = {}, onOk: () -> Unit) {
        Ui.status = "Testing connection to $host…"
        Thread {
            val r = try { Socket().use { it.connect(InetSocketAddress(host, PORT), 3000) }; null }
            catch (e: ConnectException) { "Refused: $host is reachable but nobody is hosting. Start a party on that phone first." }
            catch (e: SocketTimeoutException) { "Timeout: wrong IP, different Wi-Fi, or the router blocks phone-to-phone traffic (AP isolation)." }
            catch (e: Exception) { "${e.javaClass.simpleName}: ${e.message}" }
            runOnUiThread { if (r == null) { svc("join", host, "", pinStr); onOk() } else { Ui.status = r; onFail() } }
        }.start()
    }

    // ---------- screens: welcome -> (host setup | search -> join form) -> main ----------
    private fun showWelcome() {
        discovery?.stop()
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        l.addView(tv("Party Sync", 26f, WHITE, true))
        l.addView(tv("Tap HOST to start a party, or JOIN to find one", 13f, MUTED))
        l.addView(ModeSwitch(this) { host -> isHost = host; if (host) showHostSetup() else showSearch() },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(40) })
        setScreen("welcome", l)
    }

    private fun showHostSetup() {
        val name = field("Enter party name (optional)", GREEN); val pw = field("Enter a password (optional)", GREEN, true)
        val inner = col(); add(inner, name, 0); add(inner, pw, 12)
        add(inner, pill("Create", GREEN) { createParty(name.text.toString().trim(), pw.text.toString().trim()) }, 14)
        setScreen("host", panel(0xFF0C1F0C.toInt(), GREEN, "Create a party", inner))
    }

    private fun createParty(name: String, pw: String) {
        isHost = true; partyName = name.ifEmpty { Build.MODEL }; partyPin = pw
        Ui.status = "Starting party…"; Ui.title = ""
        svc("host", null, partyName, pw); showMain()
    }

    private fun showSearch() {
        found.clear(); hostBox = col(); renderHosts()
        val ipf = field("Host IP (if not listed)", BLUE)
        val inner = col(); inner.addView(hostBox)
        inner.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL
            addView(ipf, LinearLayout.LayoutParams(0, -2, 2f))
            addView(fill("Join", GREEN) { val t = ipf.text.toString().trim(); if (t.isNotEmpty()) showJoinForm(t, t) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) }) },
            LinearLayout.LayoutParams(MATCH_PARENT, -2).apply { topMargin = dp(14) })
        discovery?.stop()
        discovery = Discovery(this) { ip, name, locked -> runOnUiThread {
            if (screen == "search" && found.none { it.first == ip }) { found += Triple(ip, name, locked); renderHosts() } } }.also { it.start() }
        setScreen("search", panel(0xFF10303D.toInt(), GREEN, "Search for HOST", inner, pill("📷  Scan QR code", GREEN) { scanQr() }, pill("Rescan", BLUE) { showSearch() }))
    }

    private fun renderHosts() {
        hostBox.removeAllViews()
        if (found.isEmpty()) add(hostBox, tv("Scanning the Wi-Fi network…", 14f, MUTED), 0)
        found.forEach { (ip, name, locked) ->
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = box(Color.TRANSPARENT, WHITE, 24)
                setPadding(dp(16), dp(6), dp(8), dp(6)) }
            r.addView(tv((if (locked) "🔒 " else "") + name, 16f), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(fill("Join", GREEN) { showJoinForm(ip, name) })
            add(hostBox, r, 8)
        }
    }

    private fun showJoinForm(ip: String, hostName: String) {
        discovery?.stop()
        val name = field("Party name", BLUE).apply { setText(hostName); isEnabled = false }
        val pw = field("Enter a password (optional)", GREEN, true)
        formStatus = tv("", 13f, MUTED)
        val inner = col(); add(inner, name, 0); add(inner, pw, 12)
        val jb = fill("Join", GREEN) {}
        jb.setOnClickListener { jb.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); jb.isEnabled = false; jb.text = "Connecting…"
            probe(ip, pw.text.toString().trim(), { jb.isEnabled = true; jb.text = "Join" }) { isHost = false; partyName = hostName; showMain() } }
        add(inner, jb, 14)
        add(inner, formStatus, 8)
        setScreen("form", panel(Color.BLACK, BLUE, "Join party", inner))
    }

    private fun leave() {
        if (isHost && Ui.listeners > 0) AlertDialog.Builder(this).setTitle("Stop the party?").setMessage("${Ui.listeners} listener(s) will be disconnected.")
            .setPositiveButton("Stop") { _, _ -> doLeave() }.setNegativeButton("Keep playing", null).show() else doLeave()
    }

    private fun doLeave() {
        startService(Intent(this, PartyService::class.java).putExtra("mode", "stop"))
        Ui.status = "Idle"; Ui.title = ""; showWelcome()
    }

    // ---------- main screen: Home / Player / Connection / Settings ----------
    private fun showMain() {
        discovery?.stop(); applyRole(); setScreen("main", mainView); showTab(0)
    }

    private fun applyRole() {
        hostViews.forEach { it.visibility = if (isHost) View.VISIBLE else View.GONE }
        clientViews.forEach { it.visibility = if (isHost) View.GONE else View.VISIBLE }
        homeTitle.text = partyName.ifEmpty { "Party" }
        homeRole.text = if (isHost) "HOSTING" else "LISTENING"; homeRole.setTextColor(accent())
        leaveBtn.text = if (isHost) "Stop party" else "Leave party"
        if (isHost) addrTv.text = "📋  ${localIp()}:$PORT  (tap to copy)"
    }

    private fun showTab(i: Int) {
        tabContent.removeAllViews(); val pg = pages[i]; tabContent.addView(pg)
        pg.alpha = 0f; pg.animate().alpha(1f).setDuration(150).start()
        if (i == 1 && isHost && songs.isEmpty()) loadSongs()
        navItems.forEachIndexed { k, t -> t.setTextColor(if (k == i) accent() else MUTED) }
    }

    private fun buildMain(): View {
        bandChips.clear(); hostViews.clear(); clientViews.clear()
        // Home
        homeTitle = tv("", 24f, WHITE, true); homeRole = tv("", 13f, GREEN); homeStatus = tv("", 14f, MUTED)
        val home = col(18)
        add(home, homeTitle, 8); add(home, homeRole, 2); add(home, homeStatus, 14)
        addrTv = tv("", 14f, WHITE).apply { setOnClickListener {
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("addr", "${localIp()}:$PORT"))
            Toast.makeText(this@MainActivity, "Address copied", Toast.LENGTH_SHORT).show() } }.also { hostViews += it }
        add(home, addrTv, 10); add(home, bandChip(), 14)
        add(home, pill("📱  QR invite", GREEN) { inviteDialog() }.also { hostViews += it }, 18)
        add(home, fill("Stop party", 0xFFEF5350.toInt()) { leave() }.also { leaveBtn = it }, 14)

        // Player
        npTitle = tv("Nothing playing", 20f, WHITE, true); npTime = tv("0:00 / 0:00", 12f, MUTED)
        seek = SeekBar(this).apply { progressTintList = ColorStateList.valueOf(GREEN); thumbTintList = ColorStateList.valueOf(GREEN); setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar) { drag = true }
            override fun onStopTrackingTouch(s: SeekBar) { drag = false; PartyService.host?.let { it.seekBy(s.progress - it.pos()) } }
        }) }
        val controls = row(pill("⏮", GREEN) { PartyService.host?.prev() }, pill("⏪", GREEN) { PartyService.host?.seekBy(-10000) },
            pill("▶", GREEN) { PartyService.host?.let { if (it.playing) it.pause() else it.resume() } }.also { playBtn = it },
            pill("⏩", GREEN) { PartyService.host?.seekBy(10000) }, pill("⏭", GREEN) { PartyService.host?.next() },
            pill("🔀", GREEN) { PartyService.host?.playQueue(songs.shuffled(), 0) })
        val src = row(pill("🔊 System audio", GREEN) {
                startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7) },
            pill("🎵 My music", GREEN) { loadSongs() })
        songAd = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, songItems) {
            override fun getView(p: Int, v: View?, g: android.view.ViewGroup): View = (super.getView(p, v, g) as TextView).also {
                val on = songItems[p] == Ui.title; it.setTextColor(if (on) GREEN else WHITE); it.text = (if (on) "▶  " else "") + songItems[p]
                it.background = ripple(box(Color.TRANSPARENT, 0, 12), 12); it.setPadding(dp(12), dp(14), dp(12), dp(14)) } }
        val list = ListView(this).apply { adapter = songAd; divider = null
            setOnItemClickListener { _, _, i, _ -> PartyService.host?.playQueue(songs, i) } }
        val player = col(18)
        add(player, npTitle.also { hostViews += it }, 4)
        add(player, tv("Choose what to share", 14f, MUTED).also { hostViews += it }, 16)
        add(player, bigCard("🔊", "System audio", "Share everything playing on this phone") {
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7) }.also { hostViews += it }, 10)
        add(player, bigCard("🎵", "Local music", "Music player: library, queue, shuffle, repeat") { showMusic() }.also { hostViews += it }, 10)
        ctlSw = Switch(this).apply { text = "Let listeners control playback"; setTextColor(WHITE); isChecked = Cfg.clientCtl
            setOnCheckedChangeListener { b, on -> b.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); setListenerControl(on) } }
        add(player, ctlSw.also { hostViews += it }, 18)
        add(player, tv("Listeners get play / pause / skip / ±10 s / seek buttons while you play local music.", 12f, MUTED).also { hostViews += it }, 4)

        // Listener controller: mirrors the host's player; buttons only work while the host allows it
        cTitle = tv("Waiting for the host…", 20f, WHITE, true).apply { isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }
        cSub = tv("", 13f, MUTED).apply { isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }
        cTime = tv("0:00 / 0:00", 12f, MUTED)
        cNote = tv("", 12f, MUTED).apply { gravity = Gravity.CENTER }
        cSeek = SeekBar(this).apply { progressTintList = ColorStateList.valueOf(BLUE); thumbTintList = ColorStateList.valueOf(BLUE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) cTime.text = "${fmt(p.toLong())} / ${fmt(PartyService.client?.rDur ?: 0L)}" }
                override fun onStartTrackingTouch(s: SeekBar) { cDrag = true }
                override fun onStopTrackingTouch(s: SeekBar) { cDrag = false; PartyService.client?.command(6, s.progress.toLong()) } }) }
        cPlay = pill("▶", BLUE) { PartyService.client?.let { it.command(if (it.rPlaying) 2 else 1) } }
        cBtns = listOf(pill("⏮", BLUE) { PartyService.client?.command(4) }, pill("⏪", BLUE) { PartyService.client?.command(5, -10000L) }, cPlay,
            pill("⏩", BLUE) { PartyService.client?.command(5, 10000L) }, pill("⏭", BLUE) { PartyService.client?.command(3) })
        val rc = col(16).apply { background = box(0xFF14171D.toInt(), BLUE, 22) }
        add(rc, cTitle, 0); add(rc, cSub, 2); add(rc, cSeek, 12); add(rc, cTime, 0)
        add(rc, row(*cBtns.toTypedArray()), 10); add(rc, cNote, 8)
        add(player, rc.also { clientViews += it }, 16)

        // Connection
        val conn = col(18)
        add(conn, tv("Connection", 22f, WHITE, true), 8); add(conn, bandChip(), 12)
        add(conn, tv("Listeners — tap to mute or kick", 14f, MUTED).also { hostViews += it }, 18)
        listenersBox = col()
        add(conn, ScrollView(this).apply { addView(listenersBox) }.also { hostViews += it }, 8)
        trimTv = tv("", 16f, WHITE).also { clientViews += it }; add(conn, trimTv, 18)
        add(conn, row(pill("◀ later", BLUE) { PartyService.client?.let { it.trim -= 100 } },
            pill("earlier ▶", BLUE) { PartyService.client?.let { it.trim += 100 } }).also { clientViews += it }, 8)
        add(conn, tv("Tap \"earlier\" if a Bluetooth speaker lags behind the others.", 12f, MUTED).also { clientViews += it }, 8)

        // Settings: every advanced option lives here
        val set = col(18)
        var cur: LinearLayout = set
        fun head(t: String, open: Boolean = false): TextView { // tap a section title to expand / collapse it
            val body = col(); body.visibility = if (open) View.VISIBLE else View.GONE
            val h = tv((if (open) "▾  " else "▸  ") + t, 13f, GREEN, true).apply { setPadding(0, dp(10), 0, dp(10)) }
            h.setOnClickListener { val show = body.visibility != View.VISIBLE; body.visibility = if (show) View.VISIBLE else View.GONE
                h.text = (if (show) "▾  " else "▸  ") + t; it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
            set.addView(h, LinearLayout.LayoutParams(MATCH_PARENT, -2).apply { topMargin = dp(14) }); set.addView(body); cur = body; return h
        }
        fun sw(t: String, init: Boolean, onSet: (Boolean) -> Unit): Switch = Switch(this).apply { text = t; isChecked = init; setTextColor(WHITE)
            setOnCheckedChangeListener { b, on -> b.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onSet(on); Cfg.save(this@MainActivity) } }.also { add(cur, it, 8) }
        fun slider(label: String, max: Int, init: Int, onChange: (Int) -> Unit): SeekBar {
            add(cur, tv(label, 14f, MUTED), 14)
            return SeekBar(this).apply { this.max = max; progress = init; progressTintList = ColorStateList.valueOf(GREEN); thumbTintList = ColorStateList.valueOf(GREEN)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) { Cfg.save(this@MainActivity) } }) }.also { add(cur, it, 2) }
        }
        add(cur, tv("Settings", 22f, WHITE, true), 8)

        head("AUDIO", true)
        sw("Sync volume with host buttons", Ui.syncVol) { Ui.syncVol = it; PartyService.host?.pushVolume(); if (it) PartyService.client?.applyVol() }
        add(cur, tv("Stereo split (this phone)", 14f, MUTED).also { clientViews += it }, 14)
        add(cur, row(pill("🔈 L", BLUE) { PartyService.client?.setChannel(1) }, pill("Both", BLUE) { PartyService.client?.setChannel(0) },
            pill("R 🔈", BLUE) { PartyService.client?.setChannel(2) }).also { clientViews += it }, 4)

        head("HEADPHONES & SOUND")
        val am = getSystemService(android.media.AudioManager::class.java)
        add(cur, tv("This phone's volume", 14f, MUTED), 8)
        volSeek = SeekBar(this).apply { max = am.getStreamMaxVolume(3); progress = am.getStreamVolume(3); progressTintList = ColorStateList.valueOf(GREEN); thumbTintList = ColorStateList.valueOf(GREEN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) am.setStreamVolume(3, p, 0) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {} }) }
        add(cur, volSeek, 2)
        devBtn = pill("", WHITE) { pickOutput() }; add(cur, devBtn, 12); devBtn.text = outLabel()
        sw("Equalizer", Cfg.eqOn) { Cfg.eqOn = it; Fx.refresh() }
        val presets = listOf("Flat" to intArrayOf(0, 0, 0, 0, 0), "Bass" to intArrayOf(600, 400, 0, 0, 0),
            "Vocal" to intArrayOf(-200, 0, 400, 300, -100), "Treble" to intArrayOf(0, 0, 0, 400, 700))
        add(cur, row(*presets.map { (n, v) -> pill(n, GREEN) { for (i in 0..4) { Cfg.eqLv[i] = v[i]; eqBars[i].progress = v[i] + 1200 }
            Cfg.eqOn = true; Fx.refresh(); Cfg.save(this) } }.toTypedArray()), 6)
        eqBars.clear()
        listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz").forEachIndexed { i, l ->
            eqBars += slider(l, 2400, Cfg.eqLv[i] + 1200) { Cfg.eqLv[i] = it - 1200; Fx.refresh() } }
        slider("Bass boost", 1000, Cfg.bass) { Cfg.bass = it; Fx.refresh() }
        slider("Spatial sound (3D headphone virtualizer)", 1000, Cfg.spatial) { Cfg.spatial = it; Fx.refresh() }
        add(cur, tv("Effects depend on your phone and headphones; some devices support only some of them. Band frequencies are typical values.", 12f, MUTED), 6)

        head("LATENCY")
        val mb = ArrayList<Button>()
        fun paint() { mb.forEachIndexed { i, x -> x.background = box(if (i == Cfg.mode) GREEN else Color.TRANSPARENT, GREEN, 24); x.setTextColor(if (i == Cfg.mode) Color.BLACK else GREEN) } }
        listOf("⚡ Ultra-low", "Balanced", "Stable").forEachIndexed { i, t -> mb += pill(t, GREEN) { Cfg.mode = i; Cfg.save(this); PartyService.client?.applyMode(); paint() } }
        add(cur, row(*mb.toTypedArray()), 8); paint()
        add(cur, tv("Ultra-low: smallest buffer, best on 5 GHz. Stable: bigger buffer for weak Wi-Fi.", 12f, MUTED), 4)
        sw("Adaptive jitter buffer (grows when Wi-Fi hiccups)", Cfg.adaptive) { Cfg.adaptive = it }
        add(cur, tv("Latency trim (+ = this phone plays earlier)", 14f, MUTED).also { clientViews += it }, 14)
        add(cur, row(pill("◀ later", BLUE) { PartyService.client?.let { it.trim -= 100 } },
            pill("earlier ▶", BLUE) { PartyService.client?.let { it.trim += 100 } }).also { clientViews += it }, 4)

        head("NETWORK")
        sw("Priority tagging (DSCP): lower Wi-Fi queue delay", Cfg.dscp) { Cfg.dscp = it }
        sw("Pin traffic to Wi-Fi", Cfg.wifiPin) { Cfg.wifiPin = it }
        sw("Keep awake (wake lock + Wi-Fi low-latency lock)", Cfg.keepAwake) { Cfg.keepAwake = it }
        sw("Auto-reconnect", Cfg.autoReconnect) { Cfg.autoReconnect = it }.also { clientViews += it }
        add(cur, tv("Network options apply the next time you start or join a party.", 12f, MUTED), 4)

        head("HOST OPTIONS").also { hostViews += it }
        sw("Capture media audio", Cfg.capMedia) { Cfg.capMedia = it }.also { hostViews += it }
        sw("Capture game audio", Cfg.capGame) { Cfg.capGame = it }.also { hostViews += it }
        sw("Capture other / unknown audio", Cfg.capOther) { Cfg.capOther = it }.also { hostViews += it }
        sw("Repeat queue", Cfg.repeatQueue) { Cfg.repeatQueue = it }.also { hostViews += it }
        val ml = tv("", 14f, WHITE).also { hostViews += it }
        fun showMl() { ml.text = "Max listeners: " + if (Cfg.maxListeners == 0) "unlimited" else Cfg.maxListeners.toString() }
        showMl(); add(cur, ml, 14)
        add(cur, row(pill("−", GREEN) { Cfg.maxListeners = maxOf(0, Cfg.maxListeners - 1); Cfg.save(this); showMl() },
            pill("+", GREEN) { Cfg.maxListeners += 1; Cfg.save(this); showMl() }).also { hostViews += it }, 4)
        add(cur, pill("Kick everyone", 0xFFEF5350.toInt()) { PartyService.host?.let { h -> h.listeners().forEach { h.kick(it) } } }.also { hostViews += it }, 10)

        head("DIAGNOSTICS")
        diagTv = tv("", 12f, MUTED); add(cur, diagTv, 6)

        head("OTHER")
        add(cur, pill("Wi-Fi settings (use 5 GHz)", WHITE) { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }, 8)
        add(cur, pill("Reset all settings", 0xFFEF5350.toInt()) { Cfg.reset(this); Fx.refresh(); mainView = buildMain(); updateBand(); applyRole(); setScreen("main", mainView); showTab(3) }, 10)

        pages = listOf(home, player, conn, ScrollView(this).apply { addView(set) }); tabContent = FrameLayout(this)
        val nav = LinearLayout(this).apply { background = box(Color.TRANSPARENT, WHITE, 28); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        navItems = listOf("🏠" to "Home", "🎵" to "Player", "🔗" to "Connect", "⚙" to "Settings").mapIndexed { i, (ic, lb) ->
            TextView(this).apply { text = "$ic\n$lb"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(MUTED)
                setPadding(dp(4), dp(6), dp(4), dp(6)); background = ripple(box(Color.TRANSPARENT, 0, 20), 20); setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); showTab(i) } }
                .also { nav.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) } }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            addView(tabContent, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(nav, LinearLayout.LayoutParams(MATCH_PARENT, -2).apply { topMargin = dp(8) }) }
    }

    // ---------- dialogs ----------
    private fun loadSongs() { Thread {
        val s = try { scanSongs(this) } catch (e: Exception) { null }
        runOnUiThread { if (s == null) Toast.makeText(this, "Allow music access to list your songs", Toast.LENGTH_LONG).show()
            else { songs = s; songItems.clear(); songItems += s.map { it.title }; songAd.notifyDataSetChanged(); if (musicView != null) rebuildRows() } }
    }.start() }

    private fun peerDialog(h: Host, p: Peer) = AlertDialog.Builder(this).setTitle(p.name)
        .setItems(arrayOf(if (p.muted) "Unmute" else "Mute", "Volume…", "Kick")) { _, k ->
            when (k) { 0 -> h.mute(p, !p.muted); 1 -> volDialog(h, p); else -> h.kick(p) } }.show()

    private fun volDialog(h: Host, p: Peer) {
        val sb = SeekBar(this).apply { max = 100; progress = (p.gain * 100).toInt(); setPadding(dp(24), dp(24), dp(24), dp(8)) }
        AlertDialog.Builder(this).setTitle("${p.name} volume").setView(sb)
            .setPositiveButton("Set") { _, _ -> h.setGain(p, sb.progress / 100f) }.setNegativeButton("Cancel", null).show()
    }

    private fun devName(d: AD): String {
        val b = when (d.type) {
            AD.TYPE_BUILTIN_SPEAKER -> "Phone speaker"; AD.TYPE_BUILTIN_EARPIECE -> "Earpiece"; AD.TYPE_BLUETOOTH_A2DP -> "Bluetooth"
            AD.TYPE_WIRED_HEADPHONES, AD.TYPE_WIRED_HEADSET -> "Wired headphones"; AD.TYPE_USB_HEADSET, AD.TYPE_USB_DEVICE -> "USB audio"
            else -> "Other" }
        return b + (d.productName?.let { " – $it" } ?: "")
    }
    private fun outs(): List<AD> = getSystemService(android.media.AudioManager::class.java)
        .getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS).toList()
    private fun outLabel() = "🎧 Output: " + (outs().firstOrNull { it.id == Cfg.outDev }?.let { devName(it) } ?: "Auto (system default)")
    private fun pickOutput() {
        val l = outs()
        AlertDialog.Builder(this).setTitle("Play through")
            .setItems((listOf("Auto (system default)") + l.map { devName(it) }).toTypedArray()) { _, k ->
                Cfg.outDev = if (k == 0) 0 else l[k - 1].id; Cfg.save(this); devBtn.text = outLabel()
                PartyService.client?.applyOutput(); PartyService.host?.player?.applyOutput() }.show()
    }

    private fun qr(text: String): Bitmap {
        val m = com.google.zxing.qrcode.QRCodeWriter().encode(text, com.google.zxing.BarcodeFormat.QR_CODE, 600, 600)
        val bmp = Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565)
        for (x in 0 until 600) for (y in 0 until 600) bmp.setPixel(x, y, if (m.get(x, y)) Color.BLACK else Color.WHITE)
        return bmp
    }

    private fun inviteDialog() {
        val link = "partysync://join?ip=${localIp()}&pin=$partyPin"
        val iv = ImageView(this).apply { setImageBitmap(qr(link)); setPadding(dp(16), dp(16), dp(16), dp(16)) }
        AlertDialog.Builder(this).setTitle("Scan with the phone camera to join").setView(iv)
            .setNeutralButton("Share link") { _, _ -> startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link), null)) }
            .setPositiveButton("Close", null).show()
    }

    /** In-app scanner (Google code scanner: no camera permission needed, handled by Play services). */
    private fun scanQr() {
        val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        GmsBarcodeScanning.getClient(this, opts).startScan()
            .addOnSuccessListener { b ->
                val raw = b.rawValue ?: ""
                if (raw.startsWith("partysync://")) handleLink(Intent().setData(Uri.parse(raw)))
                else Toast.makeText(this, "That is not a Party Sync QR code", Toast.LENGTH_LONG).show() }
            .addOnFailureListener { e -> Toast.makeText(this, "Scanner unavailable (${e.message}). Use the phone camera app instead.", Toast.LENGTH_LONG).show() }
    }

    private fun handleLink(i: Intent?) {
        val u = i?.data ?: return; if (u.scheme != "partysync") return
        val h = u.getQueryParameter("ip") ?: return
        isHost = false; showJoinForm(h, "Party") // the form shows connection errors
        probe(h, u.getQueryParameter("pin") ?: "") { partyName = "Party"; showMain() }
    }

    // ---------- local music player: library screen + now-playing screen ----------
    private class Row(val title: String, val sub: String, val song: Song?, val track: Boolean, val onClick: () -> Unit)
    private val rows = ArrayList<Row>()
    private var viewSongs = listOf<Song>()
    private var seg = 0; private var query = ""; private var sortMode = 0
    private var filterPred: ((Song) -> Boolean)? = null
    private var filterLabel: String? = null
    private var musicView: View? = null; private var npView: View? = null
    private var lastSongId = -1L; private var npDrag = false
    private lateinit var musicAd: BaseAdapter; private lateinit var chip: TextView; private lateinit var searchF: EditText
    private lateinit var segBtns: List<Button>
    private lateinit var mini: View; private lateinit var miniArt: ImageView; private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView; private lateinit var miniPlay: Button; private lateinit var miniBar: ProgressBar
    private lateinit var npArt: ImageView; private lateinit var npT: TextView; private lateinit var npS: TextView
    private lateinit var npCur: TextView; private lateinit var npDur: TextView; private lateinit var npSeekB: SeekBar
    private lateinit var npPlayB: Button; private lateinit var npShufB: Button; private lateinit var npRepB: Button
    private lateinit var npLis: TextView
    // host: listener-control toggle. listener: remote controller mirroring the host's player
    private lateinit var npCtlB: Button; private lateinit var ctlSw: Switch
    private lateinit var cTitle: TextView; private lateinit var cSub: TextView; private lateinit var cTime: TextView; private lateinit var cNote: TextView
    private lateinit var cSeek: SeekBar; private lateinit var cPlay: Button; private lateinit var cBtns: List<Button>
    private var cDrag = false

    private fun setListenerControl(on: Boolean) { val h = PartyService.host
        if (h != null) h.setClientControl(on) else { Cfg.clientCtl = on; Cfg.save(this) } }

    /** Keeps the listener's controller in step with the host's player (called every tick). */
    private fun updateRemote(c: Client) {
        val live = c.rLive; val has = c.rHas; val ok = c.rCtl && !live && has
        cTitle.text = when { live -> "Live system audio"; has -> c.rTitle; else -> "Waiting for the host…" }
        cSub.text = if (has && !live) c.rArtist else ""
        cPlay.text = if (c.rPlaying) "⏸" else "▶"
        cBtns.forEach { it.isEnabled = ok; it.alpha = if (ok) 1f else 0.35f }
        cSeek.isEnabled = ok
        cNote.text = when { live -> "Live audio can't be paused or seeked"; !has -> "Nothing is playing yet"
            !c.rCtl -> "The host has turned off listener controls"; else -> "⏪ ⏩ jump 10 seconds" }
        if (!cDrag) { val d = c.rDur.toInt().coerceAtLeast(1); cSeek.max = d; val p = c.rPos(); cSeek.progress = p.toInt().coerceIn(0, d)
            cTime.text = "${fmt(p)} / ${fmt(c.rDur)}" }
    }

    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun artView(r: Int = 10) = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP
        background = box(0xFF20242E.toInt(), 0, r); clipToOutline = true }
    private fun setArt(iv: ImageView, s: Song?, px: Int = 160) { iv.tag = s?.id; iv.setImageDrawable(null)
        if (s != null) Art.load(this, s, px) { b -> if (iv.tag == s.id) iv.setImageBitmap(b) } }

    private fun rebuildRows() {
        val q = query.trim().lowercase()
        fun hit(s: Song) = q.isEmpty() || s.title.lowercase().contains(q) || s.artist.lowercase().contains(q) || s.album.lowercase().contains(q)
        rows.clear()
        if (seg == 0) {
            val l = songs.filter { hit(it) && (filterPred?.invoke(it) ?: true) }.let { l -> when (sortMode) {
                0 -> l.sortedBy { it.title.lowercase() }; 1 -> l.sortedBy { it.artist.lowercase() }
                2 -> l.sortedBy { it.album.lowercase() }; else -> l.sortedBy { it.dur } } }
            viewSongs = l
            l.forEachIndexed { i, s -> rows += Row(s.title, "${s.artist} · ${fmt(s.dur)}", s, true) { PartyService.host?.playQueue(viewSongs, i) } }
        } else {
            val byAlbum = seg == 1
            songs.filter { hit(it) }.groupBy { if (byAlbum) it.album else it.artist }.entries.sortedBy { it.key.lowercase() }.forEach { (k, l) ->
                rows += Row(k, if (byAlbum) "${l[0].artist} · ${l.size} songs" else "${l.size} songs", l[0], false) {
                    filterPred = { s: Song -> (if (byAlbum) s.album else s.artist) == k }
                    filterLabel = (if (byAlbum) "Album: " else "Artist: ") + k; seg = 0; refreshSeg() } }
        }
        musicAd.notifyDataSetChanged()
        chip.visibility = if (filterLabel != null && seg == 0) View.VISIBLE else View.GONE; chip.text = "✕  ${filterLabel ?: ""}"
    }

    private fun refreshSeg() {
        segBtns.forEachIndexed { i, b -> b.background = box(if (i == seg) GREEN else Color.TRANSPARENT, GREEN, 24); b.setTextColor(if (i == seg) Color.BLACK else GREEN) }
        rebuildRows()
    }

    private fun songMenu(s: Song) { val h = PartyService.host ?: return
        AlertDialog.Builder(this).setTitle(s.title).setItems(arrayOf("Play next", "Add to queue")) { _, k ->
            if (k == 0) h.addNext(s) else h.addToQueue(s)
            Toast.makeText(this, if (k == 0) "Playing next" else "Added to queue", Toast.LENGTH_SHORT).show() }.show() }

    private fun queueDialog() { val h = PartyService.host ?: return; val l = h.queue
        if (l.isEmpty()) return
        AlertDialog.Builder(this).setTitle("Queue (${l.size})")
            .setItems(l.mapIndexed { i, s -> (if (i == h.idx) "▶  " else "") + s.title }.toTypedArray()) { _, i -> h.playAt(i) }.show() }

    private fun showMusic() {
        if (musicView == null) musicView = buildMusic()
        if (songs.isEmpty()) loadSongs()
        lastSongId = -1; refreshSeg(); setScreen("music", musicView!!)
    }

    private fun showNowPlaying() { if (npView == null) npView = buildNp(); lastSongId = -1; setScreen("np", npView!!) }

    private fun buildMusic(): View {
        val root = col()
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(pill("←", WHITE) { showMain(); showTab(1) }, lp(dp(56), -2))
        head.addView(tv("Local music", 20f, WHITE, true), lp(0, -2, 1f).apply { leftMargin = dp(10) })
        head.addView(pill("🔍", WHITE) { searchF.visibility = if (searchF.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (searchF.visibility == View.GONE) searchF.setText("") }, lp(dp(56), -2))
        head.addView(pill("⇅", WHITE) { AlertDialog.Builder(this).setTitle("Sort by").setItems(arrayOf("Title (A–Z)", "Artist", "Album", "Duration")) { _, k ->
            sortMode = k; rebuildRows() }.show() }, lp(dp(56), -2))
        root.addView(head)
        searchF = field("Search songs, artists, albums", GREEN).apply { visibility = View.GONE
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) {}
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { query = s?.toString() ?: ""; rebuildRows() } }) }
        add(root, searchF, 8)
        segBtns = listOf("Songs", "Albums", "Artists").mapIndexed { i, t -> pill(t, GREEN) { seg = i; filterPred = null; filterLabel = null; refreshSeg() } }
        add(root, row(*segBtns.toTypedArray()), 8)
        add(root, fill("🔀  Shuffle all", GREEN) { val h = PartyService.host
            if (h != null && viewSongs.isNotEmpty()) { h.shuffle = true; h.playQueue(viewSongs, viewSongs.indices.random()) } }, 8)
        chip = tv("", 13f, GREEN).apply { visibility = View.GONE; setOnClickListener { filterPred = null; filterLabel = null; rebuildRows() } }
        add(root, chip, 6)
        musicAd = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int): Any = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: android.view.ViewGroup): View {
                val r = rows[p]; val curId = PartyService.host?.cur?.id
                val on = r.track && r.song != null && r.song.id == curId
                val line = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
                    background = ripple(box(Color.TRANSPARENT, 0, 12), 12) }
                val a = artView(); setArt(a, r.song); line.addView(a, lp(dp(48), dp(48)))
                val t = col(); add(t, tv(r.title, 15f, if (on) GREEN else WHITE, on).apply { isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }, 0)
                add(t, tv(r.sub, 12f, MUTED).apply { isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }, 2)
                line.addView(t, lp(0, -2, 1f).apply { leftMargin = dp(12) })
                if (on) line.addView(tv("♪", 18f, GREEN))
                return line
            } }
        val list = ListView(this).apply { adapter = musicAd; divider = null
            setOnItemClickListener { _, _, i, _ -> rows.getOrNull(i)?.onClick?.invoke() }
            setOnItemLongClickListener { _, _, i, _ -> val r = rows.getOrNull(i); if (r != null && r.track && r.song != null) songMenu(r.song); true } }
        root.addView(list, lp(MATCH_PARENT, 0, 1f))
        // mini player (tap it to open Now Playing)
        miniArt = artView(); miniTitle = tv("", 14f, WHITE, true).apply { isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }
        miniSub = tv("", 12f, MUTED).apply { isSingleLine = true }
        miniPlay = pill("▶", GREEN) { PartyService.host?.toggle() }
        miniBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; progressTintList = ColorStateList.valueOf(GREEN) }
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        line.addView(miniArt, lp(dp(44), dp(44)))
        val tc = col(); add(tc, miniTitle, 0); add(tc, miniSub, 0)
        line.addView(tc, lp(0, -2, 1f).apply { leftMargin = dp(10) })
        line.addView(pill("⏮", WHITE) { PartyService.host?.prev() }, lp(dp(52), -2))
        line.addView(miniPlay, lp(dp(52), -2)); line.addView(pill("⏭", WHITE) { PartyService.host?.next() }, lp(dp(52), -2))
        val m = col(8).apply { background = ripple(box(0xFF1A1D24.toInt(), 0, 18), 18); visibility = View.GONE; setOnClickListener { showNowPlaying() } }
        m.addView(line); m.addView(miniBar, lp(MATCH_PARENT, dp(6))); mini = m
        add(root, m, 8)
        return root
    }

    private fun buildNp(): View {
        val root = col(8)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(pill("⌄", WHITE) { showMusic() }, lp(dp(56), -2))
        top.addView(tv("Now playing", 16f, MUTED).apply { gravity = Gravity.CENTER }, lp(0, -2, 1f))
        top.addView(View(this), lp(dp(56), 1))
        root.addView(top)
        val sz = minOf(resources.displayMetrics.widthPixels - dp(72), dp(340))
        npArt = artView(26); root.addView(npArt, lp(sz, sz).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(14) })
        npT = tv("", 22f, WHITE, true).apply { gravity = Gravity.CENTER; isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }
        npS = tv("", 14f, MUTED).apply { gravity = Gravity.CENTER; isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }
        add(root, npT, 18); add(root, npS, 4)
        npSeekB = SeekBar(this).apply { progressTintList = ColorStateList.valueOf(GREEN); thumbTintList = ColorStateList.valueOf(GREEN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) npCur.text = fmt(p.toLong()) }
                override fun onStartTrackingTouch(s: SeekBar) { npDrag = true }
                override fun onStopTrackingTouch(s: SeekBar) { npDrag = false; PartyService.host?.seekTo(s.progress.toLong()) } }) }
        add(root, npSeekB, 14)
        npCur = tv("0:00", 12f, MUTED); npDur = tv("0:00", 12f, MUTED).apply { gravity = Gravity.END }
        add(root, row(npCur, npDur), 0)
        npShufB = pill("🔀", GREEN) { PartyService.host?.let { it.shuffleMode(!it.shuffle) } }
        npPlayB = fill("▶", GREEN) { PartyService.host?.toggle() }.apply { textSize = 24f; minHeight = dp(64); minimumHeight = dp(64) }
        npRepB = pill("🔁", GREEN) { PartyService.host?.cycleRepeat() }
        add(root, row(npShufB, pill("⏮", WHITE) { PartyService.host?.prev() }, npPlayB, pill("⏭", WHITE) { PartyService.host?.next() }, npRepB), 16)
        npLis = tv("", 13f, MUTED).apply { gravity = Gravity.CENTER }
        add(root, npLis, 14)
        npCtlB = pill("", GREEN) { setListenerControl(!Cfg.clientCtl) }
        add(root, npCtlB, 10)
        add(root, pill("📃  Up next", WHITE) { queueDialog() }, 10)
        return ScrollView(this).apply { isFillViewport = true; addView(root) }
    }

    private fun refreshMusicUi() {
        val h = PartyService.host ?: return; val c = h.cur
        val changed = (c?.id ?: -1L) != lastSongId
        if (changed) { lastSongId = c?.id ?: -1L; if (screen == "music") musicAd.notifyDataSetChanged() }
        if (screen == "music") {
            mini.visibility = if (c == null) View.GONE else View.VISIBLE
            if (c != null) { miniTitle.text = c.title; miniSub.text = c.artist; miniPlay.text = if (h.playing) "⏸" else "▶"
                miniBar.progress = if (c.dur > 0) (h.pos() * 1000 / c.dur).toInt().coerceIn(0, 1000) else 0
                if (changed) setArt(miniArt, c) }
        } else if (screen == "np" && c != null) {
            npT.text = c.title; npS.text = "${c.artist} — ${c.album}"; npDur.text = fmt(c.dur); npPlayB.text = if (h.playing) "⏸" else "▶"
            if (!npDrag) { npSeekB.max = c.dur.toInt(); npSeekB.progress = h.pos().toInt().coerceIn(0, c.dur.toInt()); npCur.text = fmt(h.pos()) }
            npShufB.background = ripple(box(if (h.shuffle) GREEN else Color.TRANSPARENT, GREEN, 24), 24)
            npShufB.setTextColor(if (h.shuffle) Color.BLACK else GREEN)
            npRepB.text = if (h.repeatMode == 2) "🔂" else "🔁"; npRepB.alpha = if (h.repeatMode == 0) 0.45f else 1f
            npCtlB.text = if (Cfg.clientCtl) "👥  Listeners can control: ON" else "👥  Listeners can control: OFF"; npCtlB.alpha = if (Cfg.clientCtl) 1f else 0.6f
            npLis.text = if (Ui.listeners > 0) "🎧  ${Ui.listeners} listening in sync" else "No listeners yet"
            if (changed) setArt(npArt, c, 600)
        }
    }

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Cfg.load(this)
        val sp = getSharedPreferences("d", 0) // remember crashes so they show on screen next launch
        sp.getString("crash", null)?.let { Ui.status = "Last crash: $it"; sp.edit().remove("crash").apply() }
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            sp.edit().putString("crash", "$e @ ${e.stackTrace.take(3).joinToString()}").commit(); Process.killProcess(Process.myPid()) }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += listOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else perms += Manifest.permission.READ_EXTERNAL_STORAGE
        requestPermissions(perms.toTypedArray(), 1)

        frame = FrameLayout(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); addView(frame)
            setOnApplyWindowInsetsListener { v, i -> @Suppress("DEPRECATION")
                v.setPadding(dp(14), i.systemWindowInsetTop + dp(10), dp(14), i.systemWindowInsetBottom + dp(10)); i } }
        setContentView(root)
        mainView = buildMain(); updateBand()
        val h = PartyService.host
        if (h != null || PartyService.client != null) { isHost = h != null; partyName = h?.partyName ?: ""; showMain() } else showWelcome()
        handleLink(intent)

        ui.post(object : Runnable { var n = 0
            override fun run() {
                if (screen == "music" || screen == "np") refreshMusicUi()
                homeStatus.text = Ui.status + if (Ui.listeners > 0) "  ·  ${Ui.listeners} listening" else ""
                val st = Ui.status // red = problem, amber = working on it, green = fine
                homeStatus.setTextColor(when {
                    st.startsWith("Can't") || st.startsWith("Refused") || st.startsWith("Timeout") || st.startsWith("Wrong") || st.startsWith("Error") || st.contains("full") || st.startsWith("Last crash") -> 0xFFEF5350.toInt()
                    st.startsWith("Reconnecting") || st.startsWith("Testing") || st.startsWith("Starting") -> 0xFFFBBF24.toInt()
                    else -> GREEN })
                if (Ui.title != lastTitle) { lastTitle = Ui.title; songAd.notifyDataSetChanged() }
                if (screen == "form") formStatus.text = Ui.status
                npTitle.text = Ui.title.ifEmpty { "Nothing playing" }
                if (ctlSw.isChecked != Cfg.clientCtl) ctlSw.isChecked = Cfg.clientCtl
                PartyService.client?.let { updateRemote(it) }
                trimTv.text = "Latency trim: ${PartyService.client?.trim ?: 0} ms"
                diagTv.text = PartyService.client?.diag() ?: PartyService.host?.let { "Listeners ${Ui.listeners} · queue ${it.queue.size} song(s)" } ?: "Not in a party"
                PartyService.host?.let { h -> playBtn.text = if (h.playing) "⏸" else "▶"; val c = h.cur
                    if (c != null && !drag) { seek.max = c.dur.toInt(); seek.progress = h.pos().toInt().coerceIn(0, c.dur.toInt()); npTime.text = "${fmt(h.pos())} / ${fmt(c.dur)}" }
                    val ps = h.listeners(); val sig = ps.joinToString("|") { it.name + it.muted }
                    if (sig != lSig) { lSig = sig; listenersBox.removeAllViews()
                        if (ps.isEmpty()) add(listenersBox, tv("No listeners yet", 14f, MUTED), 4)
                        ps.forEach { p -> add(listenersBox, tv(p.name + if (p.muted) "  🔇" else "", 16f).apply {
                            background = ripple(box(Color.TRANSPARENT, WHITE, 24), 24); setPadding(dp(16), dp(12), dp(16), dp(12))
                            setOnClickListener { peerDialog(h, p) } }, 8) } } }
                if (n++ % 8 == 0) { updateBand(); if (isHost && screen == "main") addrTv.text = "📋  ${localIp()}:$PORT  (tap to copy)"; if (!volSeek.isPressed) volSeek.progress = getSystemService(android.media.AudioManager::class.java).getStreamVolume(3) }
                ui.postDelayed(this, 400)
            } })
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleLink(i) }

    @Deprecated("fine for a plain Activity")
    override fun onBackPressed() { when (screen) { "host", "search" -> showWelcome(); "form" -> showSearch(); "music" -> { showMain(); showTab(1) }; "np" -> showMusic(); else -> moveTaskToBack(true) } }

    @Deprecated("fine for a plain Activity")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 7 && res == RESULT_OK && data != null) startForegroundService(
            Intent(this, PartyService::class.java).putExtra("mode", "pcm").putExtra("code", res).putExtra("data", data).putExtra("pin", partyPin))
    }

    override fun onDestroy() { discovery?.stop(); ui.removeCallbacksAndMessages(null); super.onDestroy() }
}
