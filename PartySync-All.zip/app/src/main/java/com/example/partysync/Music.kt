package com.example.partysync

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import java.util.concurrent.Executors

/** Album art / embedded cover loader with a small in-memory cache. */
object Art {
    private val cache = LruCache<Long, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)
    fun load(ctx: Context, s: Song, px: Int = 300, done: (Bitmap?) -> Unit) {
        val key = s.id * 2 + (if (px > 400) 1 else 0)
        cache.get(key)?.let { done(it); return }
        pool.execute {
            val b = try { ctx.contentResolver.loadThumbnail(s.uri, Size(px, px), null) } catch (_: Exception) { null }
            if (b != null) cache.put(key, b)
            Handler(Looper.getMainLooper()).post { done(b) }
        }
    }
}
