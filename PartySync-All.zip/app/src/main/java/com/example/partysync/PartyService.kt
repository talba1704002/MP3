package com.example.partysync

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.*
import kotlin.concurrent.thread

class PartyService : Service() {
    companion object { var host: Host? = null; var client: Client? = null }

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var capGen = 0 // bumping it stops the running capture loop (each capture owns one generation)
    private var session: MediaSession? = null
    private var artBmp: Bitmap? = null
    private var artFor = -1L
    private var wl: PowerManager.WakeLock? = null
    private var fl: WifiManager.WifiLock? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    private fun pi(m: String) = PendingIntent.getService(this, m.hashCode(),
        Intent(this, PartyService::class.java).putExtra("mode", m), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    /** Lock-screen / notification / headset controls, like a native music player. */
    private fun notif(): Notification {
        val h = host; val c = h?.cur
        val b = Notification.Builder(this, "p").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(c?.title ?: "Party Sync running").setContentText(c?.artist ?: Ui.status)
            .setOngoing(true).setVisibility(Notification.VISIBILITY_PUBLIC)
        artBmp?.let { b.setLargeIcon(it) }
        if (h != null) {
            b.addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Prev", pi("prev")).build())
            b.addAction(Notification.Action.Builder(if (h.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause", pi("pp")).build())
            b.addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", pi("next")).build())
            session?.let { b.setStyle(Notification.MediaStyle().setMediaSession(it.sessionToken).setShowActionsInCompactView(0, 1, 2)) }
        }
        return b.build()
    }

    private fun setupSession(h: Host) {
        session = MediaSession(this, "PartySync").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { host?.resume() }
                override fun onPause() { host?.pause() }
                override fun onSkipToNext() { host?.next() }
                override fun onSkipToPrevious() { host?.prev() }
                override fun onSeekTo(pos: Long) { host?.seekTo(pos) }
                override fun onStop() { host?.pause() }
            })
            isActive = true
        }
        h.onState = { ui.post { updateSession() } }
        updateSession()
    }

    private fun updateSession() {
        val h = host ?: return; val s = session ?: return; val c = h.cur
        if (c != null && c.id != artFor) { artFor = c.id; artBmp = null; Art.load(this, c, 512) { artBmp = it; updateSession() } }
        val md = MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, c?.title ?: "Party Sync")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, c?.artist ?: "").putString(MediaMetadata.METADATA_KEY_ALBUM, c?.album ?: "")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, c?.dur ?: 0L)
        artBmp?.let { md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) }
        s.setMetadata(md.build())
        s.setPlaybackState(PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO)
            .setState(if (h.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, h.pos(), 1f).build())
        getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) return START_NOT_STICKY
        Cfg.load(this)
        val mode = i.getStringExtra("mode") ?: return START_NOT_STICKY
        when (mode) { // notification buttons (host only)
            "pp" -> host?.let { if (it.playing) it.pause() else it.resume() }
            "next" -> host?.next(); "prev" -> host?.prev()
        }
        if (mode == "pp" || mode == "next" || mode == "prev") return START_NOT_STICKY
        if (mode == "stop") { shutdown(); Ui.status = "Idle"; Ui.title = ""; stopSelf(); return START_NOT_STICKY }

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("p", "Party", NotificationManager.IMPORTANCE_LOW))
        val n = notif()
        startForeground(1, n, if (mode == "pcm") ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                              else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)

        if (mode == "pcm" && host != null) { // add live audio to the party that is already running
            try { startCapture(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!, host!!) } catch (e: Exception) { Ui.status = "Error: ${e.message}" }
            return START_NOT_STICKY
        }
        try {
        shutdown()
        if (Cfg.keepAwake) wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "party:wl").apply { acquire() }
        if (Cfg.keepAwake) fl = applicationContext.getSystemService(WifiManager::class.java)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "party:fl").apply { acquire() }
        // Pin all traffic to Wi-Fi so mobile data / "smart network switch" can never hijack the stream.
        val cm = getSystemService(ConnectivityManager::class.java)
        netCb = object : ConnectivityManager.NetworkCallback() { override fun onAvailable(net: Network) { cm.bindProcessToNetwork(net) } }
        if (Cfg.wifiPin) try { cm.requestNetwork(NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCb!!) } catch (_: Exception) {}

        val player = SyncPlayer(this)
        val pin = i.getStringExtra("pin") ?: ""
        if (mode == "join") {
            client = Client(this, player, pin).also { it.connect(i.getStringExtra("ip")!!) }
        } else {
            val h = Host(this, player); h.pin = pin; h.partyName = i.getStringExtra("name") ?: ""; host = h; h.start(); setupSession(h)
            if (mode == "pcm") startCapture(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!, h)
        }
        } catch (e: Exception) { Ui.status = "Error: ${e.message}" }
        return START_NOT_STICKY
    }

    /** "Screen share" path: MediaProjection + AudioPlaybackCapture grabs all media/game audio in 5 ms slices. */
    private fun startCapture(code: Int, data: Intent, h: Host) {
        capGen++; val gen = capGen // invalidates any capture that is still running
        val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        // "Stop sharing" from the system UI ends live mode -- but only if this capture is still the current one
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() { if (capGen == gen) { capGen++; host?.endLive() } } }, ui)
        val cb = AudioPlaybackCaptureConfiguration.Builder(proj)
        if (Cfg.capMedia || !(Cfg.capGame || Cfg.capOther)) cb.addMatchingUsage(AudioAttributes.USAGE_MEDIA)
        if (Cfg.capGame) cb.addMatchingUsage(AudioAttributes.USAGE_GAME)
        if (Cfg.capOther) cb.addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
        val cap = cb.build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        @Suppress("MissingPermission")
        val rec = AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cap)
            .setBufferSizeInBytes(maxOf(min, MAXPKT * 4)).build()
        var pb = Cfg.pktBytes; h.setPcm(RATE, 2, pb)
        h.captureStop = { if (capGen == gen) capGen++ }; if (h.playing) h.pause() // live audio replaces local music
        rec.startRecording()
        thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buf = ByteArray(MAXPKT)
            while (capGen == gen) {
                val want = Cfg.pktBytes; if (want != pb) { pb = want; h.setPcm(RATE, 2, pb) } // host changed the packet size live: tell listeners
                val n = rec.read(buf, 0, pb, AudioRecord.READ_BLOCKING); if (n > 0) h.sendPcm(buf, n) }
            rec.stop(); rec.release(); proj.stop()
        }
    }

    private fun shutdown() {
        capGen++
        wl?.takeIf { it.isHeld }?.release(); fl?.takeIf { it.isHeld }?.release(); wl = null; fl = null
        netCb?.let { try { getSystemService(ConnectivityManager::class.java).apply { bindProcessToNetwork(null); unregisterNetworkCallback(it) } } catch (_: Exception) {} }
        netCb = null
        session?.release(); session = null; artBmp = null; artFor = -1L
        host?.stop(); client?.stop(); host = null; client = null
    }

    override fun onDestroy() { shutdown() }
}
