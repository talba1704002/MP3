package com.example.partysync

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.*
import kotlin.concurrent.thread

class PartyService : Service() {
    companion object { var host: Host? = null; var client: Client? = null }

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var capturing = false
    private var wl: PowerManager.WakeLock? = null
    private var fl: WifiManager.WifiLock? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    private fun pi(m: String) = PendingIntent.getService(this, m.hashCode(),
        Intent(this, PartyService::class.java).putExtra("mode", m), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) return START_NOT_STICKY
        Cfg.load(this)
        val mode = i.getStringExtra("mode") ?: return START_NOT_STICKY
        when (mode) { // notification buttons (host only)
            "pp" -> host?.let { if (it.playing) it.pause() else it.resume() }
            "next" -> host?.next(); "prev" -> host?.prev()
        }
        if (mode == "pp" || mode == "next" || mode == "prev") return START_NOT_STICKY
        if (mode == "stop") { shutdown(); Ui.status = "Idle"; Ui.title = ""; stopSelf(); return START_NOT_STICKY }

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("p", "Party", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "p").setContentTitle("Party Sync running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Prev", pi("prev")).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Play/Pause", pi("pp")).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", pi("next")).build()).build()
        startForeground(1, n, if (mode == "pcm") ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                              else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)

        if (mode == "pcm" && host != null) { // add live audio to the party that is already running
            try { startCapture(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!, host!!) } catch (e: Exception) { Ui.status = "Error: ${e.message}" }
            return START_NOT_STICKY
        }
        try {
        shutdown()
        if (Cfg.keepAwake) wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "party:wl").apply { acquire() }
        if (Cfg.keepAwake) fl = applicationContext.getSystemService(WifiManager::class.java)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "party:fl").apply { acquire() }
        // Pin all traffic to Wi-Fi so mobile data / "smart network switch" can never hijack the stream.
        val cm = getSystemService(ConnectivityManager::class.java)
        netCb = object : ConnectivityManager.NetworkCallback() { override fun onAvailable(net: Network) { cm.bindProcessToNetwork(net) } }
        if (Cfg.wifiPin) try { cm.requestNetwork(NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCb!!) } catch (_: Exception) {}

        val player = SyncPlayer(this)
        val pin = i.getStringExtra("pin") ?: ""
        if (mode == "join") {
            client = Client(this, player, pin).also { it.connect(i.getStringExtra("ip")!!) }
        } else {
            val h = Host(this, player); h.pin = pin; h.partyName = i.getStringExtra("name") ?: ""; host = h; h.start()
            if (mode == "pcm") startCapture(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!, h)
        }
        } catch (e: Exception) { Ui.status = "Error: ${e.message}" }
        return START_NOT_STICKY
    }

    /** "Screen share" path: MediaProjection + AudioPlaybackCapture grabs all media/game audio in 5 ms slices. */
    private fun startCapture(code: Int, data: Intent, h: Host) {
        val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() { capturing = false } }, ui)
        val cb = AudioPlaybackCaptureConfiguration.Builder(proj)
        if (Cfg.capMedia || !(Cfg.capGame || Cfg.capOther)) cb.addMatchingUsage(AudioAttributes.USAGE_MEDIA)
        if (Cfg.capGame) cb.addMatchingUsage(AudioAttributes.USAGE_GAME)
        if (Cfg.capOther) cb.addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
        val cap = cb.build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        @Suppress("MissingPermission")
        val rec = AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cap)
            .setBufferSizeInBytes(maxOf(min, FRAME * 4)).build()
        h.setPcm(RATE, 2)
        capturing = true; rec.startRecording()
        thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buf = ByteArray(FRAME)
            while (capturing) { val n = rec.read(buf, 0, FRAME, AudioRecord.READ_BLOCKING); if (n > 0) h.sendPcm(buf, n) }
            rec.stop(); rec.release(); proj.stop()
        }
    }

    private fun shutdown() {
        capturing = false
        wl?.takeIf { it.isHeld }?.release(); fl?.takeIf { it.isHeld }?.release(); wl = null; fl = null
        netCb?.let { try { getSystemService(ConnectivityManager::class.java).apply { bindProcessToNetwork(null); unregisterNetworkCallback(it) } } catch (_: Exception) {} }
        netCb = null
        host?.stop(); client?.stop(); host = null; client = null
    }

    override fun onDestroy() { shutdown() }
}
