package com.example.partysync

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.*
import kotlin.concurrent.thread

class PartyService : Service() {
    companion object {
        var host: Host? = null
        var client: Client? = null
        var onLog: ((String) -> Unit)? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private val log: (String) -> Unit = { m -> ui.post { onLog?.invoke(m) } }
    @Volatile private var capturing = false
    private var wl: PowerManager.WakeLock? = null
    private var fl: WifiManager.WifiLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) return START_NOT_STICKY
        val mode = i.getStringExtra("mode") ?: return START_NOT_STICKY
        if (mode == "stop") { shutdown(); stopSelf(); return START_NOT_STICKY }

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("p", "Party", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "p").setContentTitle("Party Sync running")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        val type = if (mode == "pcm") ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                   else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        startForeground(1, n, type)

        shutdown()
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "party:wl").apply { acquire() }
        fl = applicationContext.getSystemService(WifiManager::class.java)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "party:fl").apply { acquire() }
        val player = SyncPlayer(this)
        if (mode == "join") {
            client = Client(this, player, log, i.getStringExtra("pin") ?: "").also { it.connect(i.getStringExtra("ip")!!) }
        } else {
            val h = Host(this, player, log); h.pin = i.getStringExtra("pin") ?: ""; host = h; h.start()
            log("Hosting at ${localIp()}:$PORT")
            if (mode == "pcm") startCapture(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!, h)
        }
        return START_NOT_STICKY
    }

    /** "Screen share" path: MediaProjection + AudioPlaybackCapture grabs all media/game audio. */
    private fun startCapture(code: Int, data: Intent, h: Host) {
        val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() { capturing = false } }, ui)
        val cap = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
        val rate = 44100
        @Suppress("MissingPermission")
        val rec = AudioRecord.Builder()
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
            .setAudioPlaybackCaptureConfig(cap).build()
        h.setPcm(rate, 2)
        capturing = true; rec.startRecording()
        thread {
            val buf = ByteArray(4096) // ~23 ms of audio per packet
            while (capturing) { val n = rec.read(buf, 0, buf.size); if (n > 0) h.sendPcm(buf, n) }
            rec.stop(); rec.release(); proj.stop()
        }
    }

    private fun shutdown() {
        capturing = false
        wl?.takeIf { it.isHeld }?.release(); fl?.takeIf { it.isHeld }?.release(); wl = null; fl = null
        host?.stop(); client?.stop(); host = null; client = null
    }

    override fun onDestroy() { shutdown() }
}
